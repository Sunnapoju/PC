import { INRCurrencyPipe } from './inrcurrency.pipe';

describe('INRCurrencyPipe', () => {
  it('create an instance', () => {
    const pipe = new INRCurrencyPipe();
    expect(pipe).toBeTruthy();
  });
});
