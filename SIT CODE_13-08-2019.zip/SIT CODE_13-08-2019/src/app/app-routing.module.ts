import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { VerifyregComponent } from './verifyreg/verifyreg.component';

import { ForgotpwdComponent } from './forgotpwd/forgotpwd.component';
import { ResetpwdComponent } from './resetpwd/resetpwd.component';
import { CustomerInfoComponent } from './Customer/customer-info/customer-info.component';

import { CommonTemplateComponent } from './products/common-template/common-template.component';
import { QuickQuoteComponent } from './products/PC/quick-quote/quick-quote.component';
import { AddInfoComponent } from './products/PC/add-info/add-info.component';
import { PaymentComponent } from './payment/payment.component';
import { BillDeskComponent } from './bill-desk/bill-desk.component';

import { RouteGuardService } from './services/route-guard.service';



const routes: Routes = [
 { path: '', redirectTo: '/login', pathMatch: 'full'  },
  // { path: '', redirectTo: '/products/payment', pathMatch: 'full' },
  { path: 'login', component: LoginComponent  },
  {
    path: 'products', component: CommonTemplateComponent,
    children: [
      //  { path: '', redirectTo:'quickquote',pathMatch:'full' },
      { path: 'quickquote', component: QuickQuoteComponent , canActivate:[RouteGuardService] },
      { path: 'addInfo', component: AddInfoComponent, canActivate:[RouteGuardService] },
      { path: 'payment', component: PaymentComponent, canActivate:[RouteGuardService] },

    ],
    canActivate:[RouteGuardService]
  },
  {path:'billDesk', component:BillDeskComponent},
  { path: 'register', component: RegisterComponent  },
  { path: 'verifyRegister', component: VerifyregComponent},
  { path: 'forgotpwd', component: ForgotpwdComponent },
  { path: 'resetpwd/:user', component: ResetpwdComponent },
  { path: 'customer', component: CustomerInfoComponent, canActivate:[RouteGuardService]},

    // otherwise redirect to home
  { path: '**', redirectTo: '', pathMatch: 'full' }



];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
