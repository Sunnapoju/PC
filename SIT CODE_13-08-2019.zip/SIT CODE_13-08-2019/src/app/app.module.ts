import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { AppMaterialModule } from './core/material.module';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FlexLayoutModule } from '@angular/flex-layout';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { ErrorComponent } from './error/error.component';

import { IdealService } from './services/ideal.service';
import { VerifyregComponent } from './verifyreg/verifyreg.component';
import { HeaderComponent } from './header/header.component';
//import { PCQComponent } from './product/pc/pc-q.component';
//import { PCComponent } from './product/pc/pc.component';

import { ForgotpwdComponent } from './forgotpwd/forgotpwd.component';
import { ResetpwdComponent } from './resetpwd/resetpwd.component';
import { NgxSpinnerModule} from 'ngx-spinner'; 

import { CommonModule } from '@angular/common';
import { QuickQuoteComponent } from './products/PC/quick-quote/quick-quote.component';
import { AddInfoComponent } from './products/PC/add-info/add-info.component';
import { CommonTemplateComponent } from './products/common-template/common-template.component';


import { CustomerInfoComponent } from './Customer/customer-info/customer-info.component';
import { NewCustomerDialogComponent } from './Customer/new-customer-dialog/new-customer-dialog.component';
import { ExistingCustomerDialogComponent } from './Customer/existing-customer-dialog/existing-customer-dialog.component';
import { PaymentComponent } from './payment/payment.component';
import { BillDeskComponent } from './bill-desk/bill-desk.component';
import {  HTTP_INTERCEPTORS } from '@angular/common/http';
import {  ResponseInterceptor} from './_helpers/response.interceptor';

import { UserIdleModule } from 'angular-user-idle';
import { INRCurrencyPipe } from './pipes/inrcurrency.pipe';


@NgModule({
  
  declarations: [
    AppComponent,
    LoginComponent,
    RegisterComponent,
    ErrorComponent,
    VerifyregComponent,
    HeaderComponent,
    //PCQComponent,
    //PCComponent,
 
    ForgotpwdComponent,
    ResetpwdComponent,
    // CustomerComponent,
    // CustomerSearchDialog,

    
    QuickQuoteComponent,
    AddInfoComponent,
    CommonTemplateComponent,
    
    CustomerInfoComponent,

    NewCustomerDialogComponent,
    ExistingCustomerDialogComponent,
    PaymentComponent,
    BillDeskComponent,
    INRCurrencyPipe

  ],
  entryComponents: [NewCustomerDialogComponent, ExistingCustomerDialogComponent],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    
    AppMaterialModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule,
    CommonModule,
    FlexLayoutModule,
    NgxSpinnerModule,
    UserIdleModule
  ],
  exports: [AppMaterialModule],

  providers: [
        { provide: HTTP_INTERCEPTORS, useClass: ResponseInterceptor, multi: true },IdealService
   ],
  bootstrap: [AppComponent]
})
export class AppModule { }
