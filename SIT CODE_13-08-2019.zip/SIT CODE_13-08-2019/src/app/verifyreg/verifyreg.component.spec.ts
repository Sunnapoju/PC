import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { VerifyregComponent } from './verifyreg.component';

describe('VerifyregComponent', () => {
  let component: VerifyregComponent;
  let fixture: ComponentFixture<VerifyregComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ VerifyregComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(VerifyregComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
