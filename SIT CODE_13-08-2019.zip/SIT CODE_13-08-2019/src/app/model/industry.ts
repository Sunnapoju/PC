export interface Industry {
    id:string;
    value:string;
}

