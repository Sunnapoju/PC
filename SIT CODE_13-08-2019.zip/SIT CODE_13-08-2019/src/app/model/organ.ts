export interface Organ {
    id:string;
    value:string;
}
