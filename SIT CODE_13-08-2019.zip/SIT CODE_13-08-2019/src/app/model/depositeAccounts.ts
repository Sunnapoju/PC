export interface DepositAccounts {
    id: number;
    value: string;  
}

