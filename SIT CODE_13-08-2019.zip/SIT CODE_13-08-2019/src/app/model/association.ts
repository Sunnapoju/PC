export interface Association {
    id:string;
    value:string;
    
}
