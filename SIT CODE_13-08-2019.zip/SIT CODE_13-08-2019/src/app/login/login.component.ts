import { Component, OnInit, ViewChild,
  ElementRef } from '@angular/core';
import { AuthenticateService } from '../services/authenticate.service';
import { IdealService } from '../services/ideal.service';
import { Router } from '@angular/router';
import ADDConstant from '../data/add-constant.json';
import { UserIdleService } from 'angular-user-idle';
import * as $ from 'jquery';
import * as _ from 'lodash';
import { CommonServiceService } from '../services/common-service.service';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})




//instantiate create an object from class


export class LoginComponent implements OnInit {

  //username = '9000008029';
  //password = 'NicAgent@123';


 /* agentData={  
   "responseMessage":"The request successfully completed !!!",
   "responseCode":"999",
   "Agreement Codes":[  
      "500100046621900000053801"
   ],
   "Address":[  
      {  
         "PinCode":"",
         "Mobile ":"0",
         "Country":"",
         "City":"",
         "AddressID":"872664",
         "State":"",
         "District":"",
         "City Name":"",
         "Address":"19, Potters Street, Saidapet, Chennai 600 015",
         "AddressTypeName ":"Permanent",
         "AddressType":"1",
         "CountryCode":"91",
         "Beat Code":""
      },
      {  
         "PinCode":"100825",
         "Mobile ":"0",
         "Country":"India",
         "City":"600001",
         "AddressID":"872665",
         "State":"43",
         "District":"43002",
         "City Name":"Chennai",
         "Address":"19, Potters Street, Saidapet, Chennai 600 015",
         "AddressTypeName ":"Current",
         "AddressType":"2",
         "CountryCode":"91",
         "Beat Code":""
      }
   ],
   "bank":[  
      {  
         "RTGSCode":"TNSC0000001",
         "paymentMode":"1",
         "AccountNumber":"226006880",
         "BankName":"Tamil Nadu State Apex Co-Op Bank Ltd",
         "BranchAddress":"No:233, N S C Bose Road, Chennai",
         "NEFTCode":"TNSC0000001",
         "bankCode":"920091",
         "MICRCode":"600091001",
         "BankCityCode":"600001",
         "AccountId":"763338",
         "branchName":"Chennai - Head Office",
         "BranchNameCode":"92009100000001",
         "AccountType":"PRIMARY",
         "bankAccountName":"S ARASU"
      }
   ],
   "personal Info":[  
      {  
         "PANNumber":"ABIPA5310G",
         "Sector":"",
         "SecondaryEmailAdress":"",
         "Territory":"",
         "LastName":"ARASU",
         "PartyCategoryCode":"13",
         "IsCentralisedPayment":"",
         "Income":"",
         "PrimaryEmailAdress":"",
         "Physicaly_challenged":"",
         "LicenseNumber":"1664274",
         "FullName":"S ARASU",
         "Occupation":"",
         "Segment":"",
         "FirstName":"S",
         "MaritalStatus":"",
         "AssesseeCode":"",
         "ServiceTaxCode":"03500000150010000000000000033",
         "BirthDate":"1966-01-03 00:00:00",
         "Nationality":"",
         "LicenseFromDate":"2010-04-22 00:00:00",
         "AgentCode":"9000000538",
         "MiddleName":"",
         "LicenseToDate":"2013-04-22 00:00:00",
         "Gender":"1",
         "NameTitle":"1",
         "Language":"1005",
         "ServiceTaxRegNo":"",
         "PartyCategoryName":"Individual Agent"
      }
   ]
};*/
 agentData;
  username = '';
  password = '';
  errorMessage = 'Invalid Credentials';
  invalidLogin = false;
  mode = 'determinate';
  tempPolicySOABO = ADDConstant.policySOABO;
  private _shown = false;
  userData:any;
  constructor(private cs:CommonServiceService,private router: Router, private authenticateService: AuthenticateService,private _idealService : IdealService) { }



  ngOnInit( ) {




  }

  passShow(){
   console.log($("#password").attr('type'));

 var passEle= $("#password")
  if (passEle.attr('type')== "password") {
    passEle.prop('type', 'text');
  } else {
    passEle.prop('type', 'password'); 
  }

//console.log(this.passwordshow.type);
  }

  login(e,valid) {
   if (e && !valid) {
      e.preventDefault();
    }
    if(valid){
    console.log(this.username);
  


    this.authenticateService.executeJWTAuthenticationService(this.username, this.password)
      .subscribe(
        data => {
          console.log(data)
          this.userData=data;
          
          this.tempPolicySOABO.agentCode=this.username;
         
         
           ADDConstant.policySOABO=this.tempPolicySOABO;
           this._idealService.start();
            //<<<---    using ()=> syntax
      

         
          this.invalidLogin = false
          this.getAgentDetails(this.username);
        },
        error => {
          console.log(error)
          this.invalidLogin = true
        }
      )
  }
  }
  resetForm(){
    this.username=null;
    this.password=null;
 
  }
responseData;
  getAgentDetails(partyId){
    this.authenticateService.searchAgent(partyId).subscribe(result => {
      this.agentData=result;

      this.responseData=JSON.parse(this.agentData);
console.log(this.responseData);
       this.cs.setUserData(this.responseData['personal Info'][0]);
     console.log(this.responseData['Agreement Codes']);
      this.cs.setAgreementCode(this.responseData['Agreement Codes']);
      this.tempPolicySOABO.agentCode=this.username;
       ADDConstant.policySOABO=this.tempPolicySOABO;
      console.log(this.responseData['personal Info'][0].FullName);
      this.router.navigateByUrl("/products/quickquote");
    /*   if(!_.isEmpty( this.agentData)){
      //sessionStorage.setItem("userdata",JSON.stringify(this.agentData['personal Info'][0]));
      if(!_.isEmpty( this.agentData['personal Info'])){
      this.cs.setUserData(this.agentData['personal Info'][0]);
      console.log(this.agentData['Agreement Codes']);
      this.cs.setAgreementCode(this.agentData['Agreement Codes']);
      this.tempPolicySOABO.agentCode="9000000538";
       ADDConstant.policySOABO=this.tempPolicySOABO;
      console.log(this.agentData['personal Info'][0].FullName);
      this.router.navigateByUrl("/products/quickquote");
       }
       }
       */
 }, error => {
      console.log("123");
       

    });
  }

}
 