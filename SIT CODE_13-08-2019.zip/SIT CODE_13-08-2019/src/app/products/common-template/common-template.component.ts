import { Component, OnInit } from '@angular/core';
import { CommonServiceService } from '../../services/common-service.service';
@Component({
  selector: 'app-common-template',
  templateUrl: './common-template.component.html',
  styleUrls: ['./common-template.component.css']
})
export class CommonTemplateComponent implements OnInit {



//IconStates = ["active","pending","pending"];
//parentMessage: any = "From Parent...";
  constructor(private commonService:CommonServiceService) { }
  quote;
  premium;
  idv;
  tempresponse;
  plan;
  public icon1Color="#2d237d"
  ngOnInit() {
    this.commonService.common.subscribe(data => {
      this.tempresponse=data;
      this.quote=this.tempresponse.quoteNo;
      this.premium=this.tempresponse.premium;
      this.idv=this.tempresponse.idv;
      this.plan=this.tempresponse.plan;
    });
  }

}
