import { Component, OnInit, Input } from '@angular/core';
import { FormControl, FormGroupDirective, NgForm, Validators } from '@angular/forms';
import { Observable } from 'rxjs';
import { map, startWith } from 'rxjs/operators';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import moment from 'moment';
import { Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { CommonServiceService } from '../../../services/common-service.service';
import { PcServiceService } from '../../../services/pc-service.service';
import { API_URL } from '../../../app.constants';
import { CustomerService} from '../../../services/customer.service';

//import ADDConstant from '../../data/pc-constant.json';
import ADDConstant from '../../../data/add-constant.json';
//import { AddInfoComponent } from '../add-info/add-info.component';
import * as _ from 'lodash';


import 'hammerjs';

import {DateAdapter,MAT_DATE_FORMATS,MAT_DATE_LOCALE} from '@angular/material/core';
import{MomentDateAdapter} from '@angular/material-moment-adapter';

export const MY_FORMATS = {
  parse: {
    dateInput: 'DD/MM/YYYY'
  },
  display: {
    dateInput: 'DD/MM/YYYY',
    monthYearLabel: 'MMMM Y',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'MMMM Y'
  },
}; 

@Component({
    selector: 'app-quick-quote',
    templateUrl: './quick-quote.component.html',
    styleUrls: ['./quick-quote.component.css'],
     providers: [{provide: DateAdapter, useClass: MomentDateAdapter, deps: [MAT_DATE_LOCALE]},
     {provide: MAT_DATE_FORMATS, useValue: MY_FORMATS},
  ],
})
export class QuickQuoteComponent implements OnInit {


    // childmessage : string = "I am passed from Parent to child component";
    //@Input() greetMessage: string = "I am passed from Parent to child component";


    selected: any = '';
    addinf: any;
    json: any = ADDConstant;
    planObject = ADDConstant.planArray;
    tempPortalServiceInputObj = ADDConstant.portalServiceInputObj;
    tempPolicyBODynObjListArr = ADDConstant.policyBODynObjListArr;
    tempInsuredBODynObjListArr = ADDConstant.insuredBODynObjListArr;
    tempInsuredBOFieldValueMap = ADDConstant.insuredBOFieldValueMap;
    tOdPolicyCtSOABOListObj = ADDConstant.odPolicyCtSOABOListObj;
    tOdOdPolicyCtAcceSOABOListObj = ADDConstant.odOdPolicyCtAcceSOABOListObj;
    telecOdPolicyCtAcceSOABOListObj = ADDConstant.elecOdPolicyCtAcceSOABOListObj;
    tTpPolicyCtSOABOListObj = ADDConstant.tpPolicyCtSOABOListObj;
    tTpbiTpPolicyCtAcceSOABOList = ADDConstant.tpbiTpPolicyCtAcceSOABOList;
    tTppdTpPolicyCtSOABOListObj = ADDConstant.tppdTpPolicyCtAcceSOABOListObj;

    tInvoicePolicyCtSOABOListObj: any;
    tEnginePolicyCtSOABOListObj: any;

    tempPolicySOABO = ADDConstant.policySOABO;
    tempInsuredSOABOListObj = ADDConstant.insuredSOABOListObj;
    tempGenPolicyInfoSOABOObj = ADDConstant.genPolicyInfoSOABOObj;
    tempVehicleInsuredSOABOObj = ADDConstant.vehicleInsuredSOABOObj;
    tempNicPolicyCustSOABOObj = ADDConstant.nicPolicyCustSOABOObj;

    tDiscPolicyDiscSOABOListObj = ADDConstant.discPolicyDiscSOABOListObj;
    tLoadPolicyDiscSOABOListObj = ADDConstant.loadPolicyDiscSOABOListObj;
    tPolicyPaymentSOABOObj = ADDConstant.policyPaymentSOABOObj;

    // make dropdown
    makeControl = new FormControl();
    makeFiltered: Observable<any[]>;
    makeObjArr: any;
    // model dropdown
    modelControl = new FormControl();
    modelFiltered: Observable<any[]>;
    modelObjArr: any;
    // variant dropdown
    variantControl = new FormControl();
    variantFiltered: Observable<any[]>;
    variantObjArr: any;
    // rto dropdown
    rtoControl = new FormControl();
    rtoFiltered: Observable<any[]>;
    rtoObjArr: any;
    rtoSelectedObj: any;

    orginalEffectiveDate: any;
    policyEffectiveDate: any;
    policyExpiryDate: any;
    policyLiabilityExpDate: any;
    commonDateFormat = moment.HTML5_FMT.DATETIME_LOCAL_SECONDS;
    dateFormatAppend = '+05:30';
    vehicleAge: any;



    quickQuoteForm = {
        engineCover: '2',
        paOwnerDriver: '2',
        invoiceCover: '2',
        dateOfDelPurchase: new Date(),
        defaultEffectDate: new Date() // later get it from UI
    };

    title = 'NIC-Lite';
    tempIP = API_URL;

    //   tempIP = 'http://localhost:8080/';
    // tempIP = '';
    responseJsonObj2 = { quoteResult: { app: '', quoteNo: '', autoUwMsg: '', proposalStatus: '' }, saveQuoteIds: { policyId: '', payInfoId: '', insuredId: '' } };

    responseJsonObj = { app: '', quoteNo: '', autoUwMsg: '' };
    responseJsonObj1 = {};


    filterValue: any;

    // , private datePipe: DatePipe
    constructor(private router: Router,
     private httpClient: HttpClient,
     private cs:CommonServiceService,
     private spinner: NgxSpinnerService,
     private pc:PcServiceService,
     private customerService:CustomerService) { }
     private userToken;
    ngOnInit() {
        this.userToken=sessionStorage.getItem("token");
       // this.tempInsuredSOABOListObj.planId = 700015907;
        this.tempGenPolicyInfoSOABOObj.fieldValueMap.NIC_CIF_Gross_Premium_of_CIF_Policy = '0';
        this.tEnginePolicyCtSOABOListObj = ADDConstant.enginePolicyCtSOABOListObj;
        this.tInvoicePolicyCtSOABOListObj = ADDConstant.invoicePolicyCtSOABOListObj;
        this.onLoadGetCodeTables('MAKE_TABLE_QUERY:RTOCODE_TABLE_QUERY:NIL_DEPRECIATION_SLAB_TABLE_QUERY');
    }
    temRegNum;
    respRtoCode;
    RTOCode="";
    isRTOCode=false;
    isAutoRTOCode=true;
    isvaildReg=false;
    isreadOnlyPlan=false;
    planName;

loadPlanId(){
  this.cs.setPlanId(this.tempInsuredSOABOListObj.planId);
  let planId:any=this.tempInsuredSOABOListObj.planId;
  
  let index=_.findIndex( this.planObject ,function(o) {return o.id==planId });
  if(index!=-1){
    this.planName=this.planObject[index].value;
    this.cs.setPlanName(this.planName);
  
  }
    this.isreadOnlyPlan=true;

}









// auto populate RTOCode from Regiration Number
    getRTOCode(){
        this.tempVehicleInsuredSOABOObj.vehicleRegisterNo=this.tempVehicleInsuredSOABOObj.vehicleRegisterNo.toUpperCase();
        if(this.tempVehicleInsuredSOABOObj.vehicleRegisterNo.length===5 &&
         !((this.tempVehicleInsuredSOABOObj.vehicleRegisterNo.includes("NEW")))){
        this.isAutoRTOCode=false;
        this.isRTOCode=true;
        this.temRegNum=(this.tempVehicleInsuredSOABOObj.vehicleRegisterNo).toUpperCase().replace('-','');
        this.temRegNum="'"+ this.temRegNum+"'";
        console.log(this.temRegNum);
        this.pc.getRTOCodeFromReg(this.temRegNum).subscribe(result => {
        this.respRtoCode=result[0];
        if(_.isEmpty(this.respRtoCode)){
            this.isvaildReg=true;
            this.RTOCode="";
        }else{
            this.isvaildReg=false;
            this.RTOCode=this.respRtoCode.value;
             sessionStorage.setItem("rtoValue",this.RTOCode);
            this.setRtoObj(this.respRtoCode);
            console.log(this.RTOCode);
        }
    
    }, (e) => console.log(e), () => {
            console.log("error");

          });
        }else if((this.tempVehicleInsuredSOABOObj.vehicleRegisterNo.includes("NEW"))){
             this.isAutoRTOCode=true;
        this.isRTOCode=false;
        }
    }
    // auto populate related specific codes
    // Make
    buildMakeDropdown(tempObjArr: any) {
        this.makeFiltered = this.makeControl.valueChanges
            .pipe(
                startWith(''),
                map(tableObj => tableObj ? this._makeFilter(tableObj) : tempObjArr.slice())
            );
    }
    private _makeFilter(tempObj: any): any[] {
        try {
            this.filterValue = tempObj.toLowerCase();
        } catch (e) {
            this.filterValue = tempObj.value.toLowerCase();
        }
        return this.makeObjArr.filter(tableObj => tableObj.value.toLowerCase().indexOf(this.filterValue) === 0);
    }
    displayCommonFn(optionObj: any): any {
        return optionObj ? optionObj.value : optionObj;
    }
    loadModelCodTab(optionObj: any) {
        if (optionObj) {
            sessionStorage.setItem("makevalue",JSON.stringify(optionObj));
            this.tempInsuredBOFieldValueMap.NICVehicleMake = optionObj.id + '';
            this.getModelRVariantCodTab('MODEL_TABLE_QUERY:' + optionObj.id, 'MODEL');
        }
    }
    // RTO
    buildRtoDropdown(tempObjArr: any) {
        this.rtoFiltered = this.rtoControl.valueChanges
            .pipe(
                startWith(''),
                map(tableObj => tableObj ? this._rtoFilter(tableObj) : tempObjArr.slice())
            );
    }
    private _rtoFilter(tempObj: any): any[] {
        try {
            this.filterValue = tempObj.toLowerCase();
        } catch (e) {
            this.filterValue = tempObj.value.toLowerCase();
        }
        return this.rtoObjArr.filter(tableObj => tableObj.value.toLowerCase().indexOf(this.filterValue) === 0);
    }
    setRtoObj(optionObj: any) {
        if (optionObj) {
            this.rtoSelectedObj = optionObj;
            this.tempInsuredBOFieldValueMap.RegisteringAuthorityCodeName = optionObj.id.split('_')[0];
        }
    }
    // Model
    buildModelDropdown(tempObjArr: any) {
        this.modelFiltered = this.modelControl.valueChanges
            .pipe(
                startWith(''),
                map(tableObj => tableObj ? this._modelFilter(tableObj) : tempObjArr.slice())
            );
    }
    private _modelFilter(tempObj: any): any[] {
        try {
            this.filterValue = tempObj.toLowerCase();
        } catch (e) {
            this.filterValue = tempObj.value.toLowerCase();
        }
        return this.modelObjArr.filter(tableObj => tableObj.value.toLowerCase().indexOf(this.filterValue) === 0);
    }
    loadVariantCodTab(optionObj: any) {
        if (optionObj) {
            sessionStorage.setItem("modelValue",JSON.stringify(optionObj));
            this.tempInsuredBOFieldValueMap.NICVehicleModel = optionObj.id + '';
            this.getModelRVariantCodTab('VARIANT_TABLE_QUERY:' + optionObj.id, 'VARIANT');
        }
    }

    // variant
    buildVariantDropdown(tempObjArr: any) {
        console.log('Response varrr fromWhich ', tempObjArr);
        this.variantFiltered = this.variantControl.valueChanges
            .pipe(
                startWith(''),
                map(tableObj => tableObj ? this._variantFilter(tableObj) : tempObjArr.slice())
            );
    }
    private _variantFilter(tempObj: any): any[] {
        try {
            this.filterValue = tempObj.toLowerCase();
        } catch (e) {
            this.filterValue = tempObj.value.toLowerCase();
        }
        return this.variantObjArr.filter(tableObj => tableObj.value.toLowerCase().indexOf(this.filterValue) === 0);
    }
    setIdvAutopopulate(optionObj: any) {
        if (optionObj) {
            sessionStorage.setItem("varinatValue",JSON.stringify(optionObj));
            this.tempInsuredBOFieldValueMap.Variant = optionObj.id.split('_')[0] + '';
            console.log('varinatdddd : ', optionObj);
            if(this.tempInsuredSOABOListObj.planId!=100000242 && this.tempInsuredSOABOListObj.planId!=700015908){
            this.getIdvAutopopulate(optionObj.id.split('_')[1] + ':' + this.rtoSelectedObj.id.split('_')[1]);
        }
        }
    }

/*
    idvOnChange(Val) {
       // console.log("idv Onchange function called");
       // const idvOnChangeValStr = Val.toString();
      //  console.log(idvOnChangeValStr);
        this.setIDVValue(Val);
       // this.tempGenPolicyInfoSOABOObj.fieldValueMap.NIC_CIF_Gross_Premium_of_CIF_Policy = idvOnChangeValStr;
//console.log(this.tempGenPolicyInfoSOABOObj.fieldValueMap.NIC_CIF_Gross_Premium_of_CIF_Policy);
    }*/
    // all required business logic methods
    setPolicyEffectiveDate() {
        this.orginalEffectiveDate = moment(this.quickQuoteForm.defaultEffectDate).format(this.commonDateFormat);
    }
    responseidv;
    idvslab;
    
idvcalc() {
         var date = new Date(this.quickQuoteForm.dateOfDelPurchase.toString());
        var effDate = this.quickQuoteForm.defaultEffectDate;
        var timeDiff = Math.abs( date.getTime() - effDate.getTime());
        var dayDiff = Math.ceil(timeDiff / (1000 * 3600 * 24));
        let idv;
        console.log(this.tempGenPolicyInfoSOABOObj.fieldValueMap.NIC_CIF_Sum_Insured);
        console.log(dayDiff);
        if (dayDiff <= 365) {
            idv = parseInt(this.getNillDepSlab("365"));
            console.log("slab"+idv);
            console.log("this.tempGenPolicyInfoSOABOObj.fieldValueMap.NIC_CIF_Sum_Insured"+this.tempGenPolicyInfoSOABOObj.fieldValueMap.NIC_CIF_Sum_Insured);
            this.tempGenPolicyInfoSOABOObj.fieldValueMap.NIC_CIF_Gross_Premium_of_CIF_Policy = ((parseInt(this.tempGenPolicyInfoSOABOObj.fieldValueMap.NIC_CIF_Sum_Insured)) - (parseInt(this.tempGenPolicyInfoSOABOObj.fieldValueMap.NIC_CIF_Sum_Insured)) * (idv / 100)).toString();
            console.log("this.tempGenPolicyInfoSOABOObj.fieldValueMap.NIC_CIF_Sum_Insured"+this.tempGenPolicyInfoSOABOObj.fieldValueMap.NIC_CIF_Sum_Insured);
        }
        else if (dayDiff > 365 && dayDiff <= 730) {
            idv = parseInt(this.getNillDepSlab("730"));
             this.tempGenPolicyInfoSOABOObj.fieldValueMap.NIC_CIF_Gross_Premium_of_CIF_Policy = Math.ceil(((parseInt(this.tempGenPolicyInfoSOABOObj.fieldValueMap.NIC_CIF_Sum_Insured)) - parseInt((this.tempGenPolicyInfoSOABOObj.fieldValueMap.NIC_CIF_Sum_Insured)) * (idv / 100))).toString();//((this.msp)*(idv/100));
        }
        else if (dayDiff > 730 && dayDiff <= 1095) {
            idv = parseInt(this.getNillDepSlab("1095"));
             this.tempGenPolicyInfoSOABOObj.fieldValueMap.NIC_CIF_Gross_Premium_of_CIF_Policy = Math.ceil(((parseInt(this.tempGenPolicyInfoSOABOObj.fieldValueMap.NIC_CIF_Sum_Insured)) - (parseInt(this.tempGenPolicyInfoSOABOObj.fieldValueMap.NIC_CIF_Sum_Insured)) * (idv / 100))).toString();
        }
        else if (dayDiff > 1095 && dayDiff <= 1825) {
            idv = parseInt(this.getNillDepSlab("1825"));
            this.tempGenPolicyInfoSOABOObj.fieldValueMap.NIC_CIF_Gross_Premium_of_CIF_Policy =  Math.ceil(((parseInt(this.tempGenPolicyInfoSOABOObj.fieldValueMap.NIC_CIF_Sum_Insured)) - (parseInt(this.tempGenPolicyInfoSOABOObj.fieldValueMap.NIC_CIF_Sum_Insured)) * (idv / 100))).toString();
        }

        return this.tempGenPolicyInfoSOABOObj.fieldValueMap.NIC_CIF_Gross_Premium_of_CIF_Policy;

    }

    getNillDepSlab(value) {
            console.log(this.idvslab);
        let realtionObj: any = _.find(this.idvslab, {
            'value': value
        });
        
        return realtionObj.id;

    }



    preparePolicyDates() {
        this.setPolicyEffectiveDate();
        console.log(this.orginalEffectiveDate);
        this.policyEffectiveDate = this.orginalEffectiveDate + this.dateFormatAppend;
        console.log(this.policyEffectiveDate);
        const effDate = this.quickQuoteForm.defaultEffectDate;
       this.setEffectiveDates(effDate);
       
    }
    setEffectiveDates(effDate){
 if (this.tempInsuredSOABOListObj.planId === 100000241 || this.tempInsuredSOABOListObj.planId==100000242 || this.tempInsuredSOABOListObj.planId==700015908 || this.tempInsuredSOABOListObj.planId==700015907) {
            const expiryDate = new Date(effDate.getFullYear() + 1, effDate.getMonth(), effDate.getDate() - 1);
            expiryDate.setHours(23);
            expiryDate.setMinutes(59);
            expiryDate.setSeconds(59);
            const momentExpDate = moment(expiryDate).format(this.commonDateFormat);
            this.policyExpiryDate = momentExpDate + this.dateFormatAppend;
            console.log(this.policyExpiryDate);
            this.tOdPolicyCtSOABOListObj.effectiveDate= this.policyEffectiveDate;
            this.tOdPolicyCtSOABOListObj.expirtyDate=this.policyExpiryDate;
            if(this.tempInsuredSOABOListObj.planId == 700015907 ||this.tempInsuredSOABOListObj.planId == 700015908 ){
            const lExpiryDate = new Date(effDate.getFullYear() + 3, effDate.getMonth(), effDate.getDate() - 1);
            lExpiryDate.setHours(23);
            lExpiryDate.setMinutes(59);
            lExpiryDate.setSeconds(59);
            this.policyLiabilityExpDate = Date.parse(lExpiryDate + '') + '';
            console.log(this.policyLiabilityExpDate);
            this.tempGenPolicyInfoSOABOObj.fieldValueMap.NIC_Declaration_Date = this.policyLiabilityExpDate;
            const expiryDate=moment(lExpiryDate).format(this.commonDateFormat);
            this.tTpPolicyCtSOABOListObj.expirtyDate=expiryDate+ this.dateFormatAppend;
            this.tTpPolicyCtSOABOListObj.effectiveDate=this.policyEffectiveDate;
           
            }else if(this.tempInsuredSOABOListObj.planId==100000241 || this.tempInsuredSOABOListObj.planId==100000242){
                this.tempGenPolicyInfoSOABOObj.fieldValueMap.NIC_Declaration_Date="";
                this.tTpPolicyCtSOABOListObj.expirtyDate=this.policyExpiryDate;
                this.tTpPolicyCtSOABOListObj.effectiveDate=this.policyEffectiveDate;
            }
        }else if(this.tempInsuredSOABOListObj.planId==700015914){
            const expiryDate = new Date(effDate.getFullYear() + 3, effDate.getMonth(), effDate.getDate() - 1);
            expiryDate.setHours(23);
            expiryDate.setMinutes(59);
            expiryDate.setSeconds(59);
            const momentExpDate = moment(expiryDate).format(this.commonDateFormat);
            this.policyExpiryDate = momentExpDate + this.dateFormatAppend;
            this.tOdPolicyCtSOABOListObj.effectiveDate= this.policyEffectiveDate;
            this.tOdPolicyCtSOABOListObj.expirtyDate=this.policyExpiryDate;
            this.tTpPolicyCtSOABOListObj.expirtyDate=this.policyExpiryDate;
            this.tTpPolicyCtSOABOListObj.effectiveDate=this.policyEffectiveDate;
            this.tempGenPolicyInfoSOABOObj.fieldValueMap.NIC_Declaration_Date =Date.parse(expiryDate  + '') + '';
        }

}
    prepareVehicleAge() {
        const regDate = this.quickQuoteForm.dateOfDelPurchase;
        console.log(regDate);
        this.vehicleAge = this.getDiffYears(regDate, this.orginalEffectiveDate);
        console.log(this.vehicleAge);
    }
    getIDVAmount(idvResponseArr: any): any {

        const monthDiff = this.getDiffMonths(this.quickQuoteForm.dateOfDelPurchase, this.quickQuoteForm.defaultEffectDate);
        let idvValue: any = 0;
        if (monthDiff <= 6) {
            idvValue = idvResponseArr[0];
        } else if (monthDiff > 6 && monthDiff <= 12) {
            idvValue = idvResponseArr[1];
        } else {
            // needs to cross verify the 10 years
            const vehYear = Math.ceil(monthDiff / 12) + 1; // + one for index
            if (vehYear <= 11) {
                idvValue = idvResponseArr[vehYear];
            }
        }
        return idvValue;
    }
    isSubmit=false;

    enableSubmit(){

    }
    framePortalServiceInput() {

        this.preparePolicyDates();
        this.prepareVehicleAge();

        const tempVar: any = this.quickQuoteForm.dateOfDelPurchase;

        // use this must validate b4 parse here
        this.tempInsuredBOFieldValueMap.DateOfDeliveryPurchase = Date.parse(tempVar) + '';
        // this.tempInsuredBOFieldValueMap.YearOfManufacture = this.datePipe.transform(this.tempVar, 'yyyy') + '';
        this.tempVehicleInsuredSOABOObj.registrationNumber = this.tempVehicleInsuredSOABOObj.vehicleRegisterNo;
        this.tOdPolicyCtSOABOListObj.insuredId = this.responseJsonObj2.saveQuoteIds.insuredId;

    
        console.log("NEW Assign Invoice : ", this.tInvoicePolicyCtSOABOListObj);
        // clear the delete cover type list
        this.tempInsuredSOABOListObj.deletedPolicyCtSOABOList = [];
        // basic mandatory benefit
        this.tOdPolicyCtSOABOListObj.policyCtAcceSOABOList = [];
        this.tOdPolicyCtSOABOListObj.policyCtAcceSOABOList.push(this.tOdOdPolicyCtAcceSOABOListObj);
        // object used to remove policy ct id for non added covers
        let tempBoolObj: any = {isOdCover: false,isTpCover: false,isInvCover: false,isEngCover:false}
        // push into cover
        for (let [key, value] of Object.entries(this.responseJsonObj2.saveQuoteIds)) {
            let keyvalue: any = key;
            if (keyvalue == this.tOdPolicyCtSOABOListObj.coverTypeId) {

                this.tOdPolicyCtSOABOListObj.policyCtId = value;
                tempBoolObj.isOdCover = true;
            } else if (keyvalue == this.tTpPolicyCtSOABOListObj.coverTypeId) {

                this.tTpPolicyCtSOABOListObj.policyCtId = value;
                tempBoolObj.isTpCover = true;
            } else if ( keyvalue == this.tInvoicePolicyCtSOABOListObj.coverTypeId) {

                this.tInvoicePolicyCtSOABOListObj.policyCtId = value;
                tempBoolObj.isInvCover = true;
            } else if (keyvalue == this.tEnginePolicyCtSOABOListObj.coverTypeId) {

                this.tEnginePolicyCtSOABOListObj.policyCtId = value;
                tempBoolObj.isEngCover = true;
            }
        }

        if(!tempBoolObj.isOdCover){
            this.tOdPolicyCtSOABOListObj.policyCtId = "";
        }else if(!tempBoolObj.isTpCover){
            this.tTpPolicyCtSOABOListObj.policyCtId = "";
        }else if(!tempBoolObj.isInvCover){
            this.tInvoicePolicyCtSOABOListObj.policyCtId = "";
        }else if(!tempBoolObj.isEngCover){
            this.tEnginePolicyCtSOABOListObj.policyCtId = "";
        }

        this.tempInsuredSOABOListObj.policyCtSOABOList = [];
        if(this.tempInsuredSOABOListObj.planId!=100000242 && this.tempInsuredSOABOListObj.planId!=700015908){
        this.tempInsuredSOABOListObj.policyCtSOABOList.push(this.tOdPolicyCtSOABOListObj);
        }
        //this.tTpPolicyCtSOABOListObj.effectiveDate = this.policyEffectiveDate;
        //this.tTpPolicyCtSOABOListObj.expirtyDate = this.policyExpiryDate;
        this.tTpPolicyCtSOABOListObj.policyCtAcceSOABOList = [];
        this.tTpPolicyCtSOABOListObj.policyCtAcceSOABOList.push(this.tTpbiTpPolicyCtAcceSOABOList);
        this.tTpPolicyCtSOABOListObj.policyCtAcceSOABOList.push(this.tTppdTpPolicyCtSOABOListObj);
        // push into cover
        this.tempInsuredSOABOListObj.policyCtSOABOList.push(this.tTpPolicyCtSOABOListObj);
        // option covers
        if (this.quickQuoteForm.invoiceCover === '1') {

             //this.tInvoicePolicyCtSOABOListObj.policyCtId = "";
             // this.tempInsuredSOABOListObj.deletedPolicyCtSOABOList=[];
              this.tInvoicePolicyCtSOABOListObj.deletedPolicyCtAcceSOABOList=[];
            // this.tInvoicePolicyCtSOABOListObj = ADDConstant.invoicePolicyCtSOABOListObj;
            this.tInvoicePolicyCtSOABOListObj.effectiveDate = this.policyEffectiveDate;
            this.tInvoicePolicyCtSOABOListObj.expirtyDate = this.policyExpiryDate;
            this.tInvoicePolicyCtSOABOListObj.fieldValueMap.BasicIDV = this.tOdOdPolicyCtAcceSOABOListObj.interestSi;
            // push into cover
            this.tempInsuredSOABOListObj.policyCtSOABOList.push(this.tInvoicePolicyCtSOABOListObj);
        }else if(this.quickQuoteForm.invoiceCover === '0' && (this.tInvoicePolicyCtSOABOListObj.policyCtId != null && this.tInvoicePolicyCtSOABOListObj.policyCtId > 0)){
            this.tInvoicePolicyCtSOABOListObj.policyCtAcceSOABOList[0].policyCtId=this.tInvoicePolicyCtSOABOListObj.policyCtId;
           // this.tInvoicePolicyCtSOABOListObj.deletedPolicyCtAcceSOABOList.push(this.tInvoicePolicyCtSOABOListObj.policyCtAcceSOABOList[0])
            this.tempInsuredSOABOListObj.deletedPolicyCtSOABOList.push(this.tInvoicePolicyCtSOABOListObj);
           
        }
        console.log("After setting deleted Insured SOAB  : ", this.tempInsuredSOABOListObj);
        if (this.quickQuoteForm.engineCover === '1') {
             //this.tempInsuredSOABOListObj.deletedPolicyCtSOABOList=[];
              // this.tEnginePolicyCtSOABOListObj.policyCtId = "";
           // this.tEnginePolicyCtSOABOListObj = ADDConstant.enginePolicyCtSOABOListObj;
           this.tEnginePolicyCtSOABOListObj.deletedPolicyCtAcceSOABOList=[];
            this.tEnginePolicyCtSOABOListObj.effectiveDate = this.policyEffectiveDate;
            this.tEnginePolicyCtSOABOListObj.expirtyDate = this.policyExpiryDate;
            // here needs to set age of vehicle in agreed field
            this.tEnginePolicyCtSOABOListObj.fieldValueMap.AgreedValue = this.vehicleAge + '';
            // push into cover
            this.tempInsuredSOABOListObj.policyCtSOABOList.push(this.tEnginePolicyCtSOABOListObj);
        }else if(this.quickQuoteForm.engineCover === '0' &&  (this.tEnginePolicyCtSOABOListObj.policyCtId !=null && this.tEnginePolicyCtSOABOListObj.policyCtId>0) ){
            this.tempInsuredSOABOListObj.deletedPolicyCtSOABOList.push(this.tEnginePolicyCtSOABOListObj);
            
        }
        //this.tOdPolicyCtSOABOListObj.policyCtAcceSOABOList.push(this.telecOdPolicyCtAcceSOABOListObj);

        this.tempInsuredSOABOListObj.effectiveDate = this.policyEffectiveDate;
        this.tempInsuredSOABOListObj.expiryDate = this.policyExpiryDate;
        this.tempInsuredSOABOListObj.policyId = this.responseJsonObj2.saveQuoteIds.policyId;
        this.tempInsuredSOABOListObj.insuredId = this.responseJsonObj2.saveQuoteIds.insuredId;
        this.tempInsuredSOABOListObj.vehicleInsuredSOABO = this.tempVehicleInsuredSOABOObj;
        this.tempInsuredSOABOListObj.dynamicObjectList = this.tempInsuredBODynObjListArr;
        this.tempInsuredSOABOListObj.fieldValueMap = this.tempInsuredBOFieldValueMap;

        this.tempPolicySOABO.effectDate = this.policyEffectiveDate;
        this.tempPolicySOABO.expiryDate = this.policyExpiryDate;
        this.tempPolicySOABO.quotationNumber = this.responseJsonObj2.quoteResult.quoteNo;
        this.tempPolicySOABO.proposalStatus = this.responseJsonObj2.quoteResult.proposalStatus;
        this.tempPolicySOABO.policyId = this.responseJsonObj2.saveQuoteIds.policyId;


        this.tempPolicySOABO.dynamicObjectList = this.tempPolicyBODynObjListArr;
        this.tempGenPolicyInfoSOABOObj.policyId = this.responseJsonObj2.saveQuoteIds.policyId;
        this.tempPolicySOABO.genPolicyInfoSOABO = this.tempGenPolicyInfoSOABOObj;
        this.tempPolicySOABO.insuredSOABOList = [];
        this.tempPolicySOABO.insuredSOABOList.push(this.tempInsuredSOABOListObj);
        this.tempNicPolicyCustSOABOObj.policyId = this.responseJsonObj2.saveQuoteIds.policyId;
        this.tempPolicySOABO.nicPolicyCustSOABO = this.tempNicPolicyCustSOABOObj;
        this.tempPolicySOABO.policyDiscSOABOList = [];
        this.tDiscPolicyDiscSOABOListObj.policyId = this.responseJsonObj2.saveQuoteIds.policyId;
        this.tempPolicySOABO.policyDiscSOABOList.push(this.tDiscPolicyDiscSOABOListObj);
        this.tLoadPolicyDiscSOABOListObj.policyId = this.responseJsonObj2.saveQuoteIds.policyId;
        this.tempPolicySOABO.policyDiscSOABOList.push(this.tLoadPolicyDiscSOABOListObj);
        this.tPolicyPaymentSOABOObj.policyPayInfoSOABOList[0].payInfoId = this.responseJsonObj2.saveQuoteIds.payInfoId;
        this.tPolicyPaymentSOABOObj.policyPayInfoSOABOList[0].policyId = this.responseJsonObj2.saveQuoteIds.policyId;
        this.tempPolicySOABO.policyPaymentSOABO = this.tPolicyPaymentSOABOObj;

        this.tempPortalServiceInputObj.policySOABO = this.tempPolicySOABO;
        console.log('Final Prepared Object :  ', this.tempPortalServiceInputObj);
    }

    setLoadQuoteData(loadQObj: any) {
        console.log('responseJsonObj1.quoteNo', loadQObj);
        this.tempGenPolicyInfoSOABOObj = loadQObj.genPolicyInfoSOABO;
        console.log(this.tempGenPolicyInfoSOABOObj);
        this.tempVehicleInsuredSOABOObj = loadQObj.insuredSOABOList[0].vehicleInsuredSOABO;
        //this.tempInsuredBOFieldValueMap = loadQObj.insuredSOABOList[0].fieldValueMap;
        this.tempNicPolicyCustSOABOObj = loadQObj.nicPolicyCustSOABO;
        this.tPolicyPaymentSOABOObj = loadQObj.policyPaymentSOABO;

        // iterate the discount list and set into appropriate discount type object...
        let tempList = loadQObj.policyDiscSOABOList;
        for (let discObj of tempList) {
            if (discObj.discountType === "105") {
                this.tDiscPolicyDiscSOABOListObj = discObj;
            } else if (discObj.discountType === "91") {
                this.tLoadPolicyDiscSOABOListObj = discObj;
            }
        }
        this.tempInsuredSOABOListObj = loadQObj.insuredSOABOList[0];
        console.log(this.tempInsuredSOABOListObj);

        this.tempInsuredBOFieldValueMap = loadQObj.insuredSOABOList[0].fieldValueMap;

        tempList = this.tempInsuredSOABOListObj.policyCtSOABOList;

        for (let ctObj of tempList) {
            if (ctObj.coverType === 700000500) {
                this.tOdPolicyCtSOABOListObj = ctObj;
            } else if (ctObj.coverType === 700001243) {
                this.tTpPolicyCtSOABOListObj = ctObj;
            }
        }

        tempList = this.tOdPolicyCtSOABOListObj.policyCtAcceSOABOList;

        for (let ctAccObj of tempList) {
            if (ctAccObj.interestType === 700000120) {
                this.tOdOdPolicyCtAcceSOABOListObj = ctAccObj;
            } else if (ctAccObj.interestType === 100000060) {
                this.telecOdPolicyCtAcceSOABOListObj = ctAccObj;
            }
        }

        tempList = this.tTpPolicyCtSOABOListObj.policyCtAcceSOABOList;

        for (let ctAccObj of tempList) {
            if (ctAccObj.interestType === 100000040) {
                this.tTpbiTpPolicyCtAcceSOABOList = ctAccObj;
            } else if (ctAccObj.interestType === 100000041) {
                this.tTppdTpPolicyCtSOABOListObj = ctAccObj;
            }
        }

    }

    // all controller call methods
    async onLoadGetCodeTables(tableNames: string) {

    //{headers: new HttpHeaders({ 'Authorization':this.userToken}), responseType: 'json'}
        await this.httpClient.post(this.tempIP + 'quote/codeTables', tableNames,  {responseType: 'json'})
            .toPromise().then(
                data => {
                    console.log('Response data ', data);
                    const tempRespObjArr = data;
                    const tempRespObj = tempRespObjArr[0];

                    this.makeObjArr = tempRespObj.MAKE_TABLE_QUERY;
                     sessionStorage.setItem("MakeData",JSON.stringify(this.makeObjArr));
                    this.buildMakeDropdown(this.makeObjArr);
                    this.rtoObjArr = tempRespObj.RTOCODE_TABLE_QUERY;
                    this.idvslab=tempRespObj.NIL_DEPRECIATION_SLAB_TABLE_QUERY;
                      sessionStorage.setItem("nillDep",JSON.stringify( this.idvslab));
                    sessionStorage.setItem("rtoData",JSON.stringify(this.rtoObjArr));
                     
                    this.buildRtoDropdown(this.rtoObjArr);

                },
                error => {
                    console.log('Error', error);
                }
            );
    }
    async getModelRVariantCodTab(tableCodeName: string, fromWhere: string) {
        //{headers: new HttpHeaders({ 'Authorization':this.userToken}), responseType: 'json'}
        await this.httpClient.post(this.tempIP + 'quote/codeTableByCode', tableCodeName, {responseType: 'json'})
            .toPromise().then(
                data => {
                    console.log('Response ddd data ', data);
                    if (fromWhere === 'MODEL') {
                        this.modelObjArr = data;
                        this.buildModelDropdown(this.modelObjArr);
                    } else {
                        this.variantObjArr = data;
                        this.buildVariantDropdown(this.variantObjArr);
                    }
                },
                error => {
                    console.log('Error', error);
                }
            );
    }
    public idvMin: any;
    public idvMax: any;
    async getIdvAutopopulate(variantStateId: string) {
        // /{headers: new HttpHeaders({ 'Authorization':this.userToken}), responseType: 'text'}
        await this.httpClient.post(this.tempIP + 'quote/idvAutoPopulate', variantStateId, {responseType: 'text'})
            .toPromise().then(
                data => {
                    console.log('Response ddd data ', data);
                    const idvAutoPopulateArr = (data.split('~~')[0]).split('~');
                   
                    this.tempInsuredBOFieldValueMap.TypeOfBody = idvAutoPopulateArr[5] + '';
                    this.tempInsuredBOFieldValueMap.TypeOfFuel = idvAutoPopulateArr[6] + '';
                    this.tempInsuredBOFieldValueMap.NIC_PC_Cubic_Capacity = idvAutoPopulateArr[1] + '';
                    this.tempVehicleInsuredSOABOObj.numberofSeats = idvAutoPopulateArr[0];
                    this.tempGenPolicyInfoSOABOObj.fieldValueMap.NIC_CIF_Sum_Insured = idvAutoPopulateArr[2] + '';
                    this.tempInsuredBOFieldValueMap.YearOfManufacture = idvAutoPopulateArr[3] + '';

                    const idvValAutoPopulateArr = (data.split('~~')[1]).split('~');
                    let idvValue = this.getIDVAmount(idvValAutoPopulateArr);
                    console.log("idvValue  value"+idvValue);
                    console.log("idvValue  value array"+idvValAutoPopulateArr);
                    if(idvValue==0){
                       idvValue =this.idvcalc();
                    }
                    //idvValue=Math.round(idvValue);
                    this.idvMin = Math.round(((idvValue) * 0.95));
                    //console.log(this.idvMin);
                    this.idvMax = ((idvValue) * 1.05);

                    //  this.idvMax = (this.idvMin + ((idvValue / 100) * 10));
                    sessionStorage.setItem("idvMin",this.idvMin);
                    sessionStorage.setItem("idvMax", this.idvMax);
                    console.log(this.idvMin);
                    console.log(this.idvMax);

                    this.setIDVValue(idvValue);
                    this.tOdOdPolicyCtAcceSOABOListObj.fieldValueMap.IManufacturerSellingPrice = idvAutoPopulateArr[2] + '';
                 /*   const idvValueStr = idvValue + '';
                    console.log('idvValueStr' + idvValueStr);
                    this.tempGenPolicyInfoSOABOObj.fieldValueMap.NIC_CIF_Gross_Premium_of_CIF_Policy = idvValueStr;
                    this.tempGenPolicyInfoSOABOObj.fieldValueMap.NIC_Volume_Discount = idvValueStr;

                    this.tOdOdPolicyCtAcceSOABOListObj.fieldValueMap.NIC_FestivalSumInsured_Benefit = idvValueStr;
                    this.tOdOdPolicyCtAcceSOABOListObj.interestSi = idvValue;
                    this.tOdOdPolicyCtAcceSOABOListObj.fieldValueMap.IManufacturerSellingPrice = idvAutoPopulateArr[2] + '';
                    this.tOdPolicyCtSOABOListObj.fieldValueMap.NIC_Deductible3 = idvValueStr;*/
                },
                error => {
                    console.log('Error', error);
                }
            );
    }
    setIDVValue(idv){
                    this.tempGenPolicyInfoSOABOObj.fieldValueMap.NIC_CIF_Gross_Premium_of_CIF_Policy = idv.toString();
                    this.tempGenPolicyInfoSOABOObj.fieldValueMap.NIC_Volume_Discount = idv.toString();
                    this.tOdOdPolicyCtAcceSOABOListObj.fieldValueMap.NIC_FestivalSumInsured_Benefit = idv.toString();
                    this.tOdOdPolicyCtAcceSOABOListObj.interestSi = idv;
                    this.tOdPolicyCtSOABOListObj.fieldValueMap.NIC_Deductible3 = idv.toString();;
    }
    tempCommonJson = {
        quoteNo: "",
        premium: "",
        idv: "",
        plan:""

    }
    tempCommInfo={
        gmail:"",
        mobno:0
    }
/*    clear(){
        if(this.responseJsonObj2){
           
}
    }*/
    public mobNum:number;
   public sessionObject={
       agentCode:"",
       agentName:"",
       branchId:"",
       customer:{
           custId:"",
           custName:"",
           custType:""
       },
       quoteNo:"",
       premium:"",
       productCode:"",
       productName:""
   }
   userData;
   isShowSpinner=true;
    saveQuickQuote(e,valid) {
         if (e && !valid) {
      e.preventDefault();
    }
  //  this.clear()
    if(valid){
        this.loadPlanId();
        
    //{headers: new HttpHeaders({ 'Authorization':this.userToken}), responseType: 'json'}
        this.spinner.show();
     
        this.tempCommInfo.gmail=this.email.value;
        this.tempCommInfo.mobno=this.mobNum;
        this.customerService.setCommInfo(this.tempCommInfo);
        this.framePortalServiceInput();
        this.httpClient.post(this.tempIP + 'quote/saveQuote',
            JSON.stringify(this.tempPortalServiceInputObj),{ responseType: 'json'})
            .subscribe(
                data => {
                    console.log('POST Request is successful ', data);
                    this.spinner.hide();
                    const responseJson = data[0];
                    this.responseJsonObj2 = JSON.parse(responseJson);
                    console.log('responseJsonObj.quoteNo', this.responseJsonObj2);
                    sessionStorage.setItem('appinf', JSON.stringify(this.responseJsonObj2));
                    console.log(this.responseJsonObj2.quoteResult.quoteNo);
                    this.tempCommonJson.quoteNo = this.responseJsonObj2.quoteResult.quoteNo;
                    this.tempCommonJson.premium = this.responseJsonObj2.quoteResult.app;
                    this.tempCommonJson.idv = this.tempGenPolicyInfoSOABOObj.fieldValueMap.NIC_CIF_Gross_Premium_of_CIF_Policy;
                    this.tempCommonJson.plan=this.planName;
                    this.cs.common.next(this.tempCommonJson);
                  
                    this.sessionObject.premium=this.responseJsonObj2.quoteResult.app;
                    this.sessionObject.quoteNo=this.responseJsonObj2.quoteResult.quoteNo;
                    this.sessionObject.agentCode=this.tempPolicySOABO.agentCode;
                     this.userData= this.cs.getUserData();
                    this.sessionObject.agentName=this.userData.FullName;
                    
                    sessionStorage.setItem('userData', JSON.stringify(this.sessionObject));
                    this.sessionObject.branchId=this.tempPortalServiceInputObj.branchId;
                    this.sessionObject.productCode="PC";
                 this.sessionObject.productName="Private Car";
                    sessionStorage.setItem('userData',JSON.stringify(this.sessionObject));
                },
                error => {
                    console.log('Error', error);
                }
            );
       
    }
    }
    invoice: number = 0;
    invoiceprotect(value) {
        if (value.checked == true) {
            this.invoice = 1;
            this.quickQuoteForm.invoiceCover = '1';
        } else {
            this.invoice = 0;
            this.quickQuoteForm.invoiceCover = '0'
        }
    }

    engine: number = 0;

    engineprotect(value) {
        if (value.checked == true) {
            this.engine = 1;
            this.quickQuoteForm.engineCover = '1';
        } else {
            this.engine = 0;
            this.quickQuoteForm.engineCover = '0';
        }
    }
    percentagevalue: string='';
    percentcal: number;
    percentage() {

        const temppercentagevalue=parseInt(this.percentagevalue);
        if(temppercentagevalue>0){
              sessionStorage.setItem("percentage",JSON.stringify(this.percentagevalue));
        if (this.percentcal == 1) {
            this.tDiscPolicyDiscSOABOListObj.discountRate = temppercentagevalue/100;
            this.tLoadPolicyDiscSOABOListObj.discountRate=0;
            console.log('discount ', this.percentcal);
        } else {

            this.tLoadPolicyDiscSOABOListObj.discountRate = temppercentagevalue/100;
             this.tDiscPolicyDiscSOABOListObj.discountRate=0;
            console.log('loading ', this.percentcal);
        }
        }
    }



    loadQuoteByQuote() {
        //{headers: new HttpHeaders({ 'Authorization':this.userToken}), responseType: 'json'}
        this.httpClient.post(this.tempIP + 'quote/loadQuote', this.responseJsonObj.quoteNo, {responseType: 'json'})
            .subscribe(
                data => {
                    console.log('POST Request is successful ', data);

                    const responseJson1 = data[0];
                    this.responseJsonObj1 = JSON.parse(responseJson1);
                    //   this.setLoadQuoteData(this.responseJsonObj1);
                    //    this.addinf=JSON.stringify(this.tempPortalServiceInputObj);
                    //         this.router.navigate(['addInfo',this.addinf]);   
                },
                error => {
                    console.log('Error', error);
                }
            );
    }

    passaddinf() {


        console.log('success', this.responseJsonObj2.quoteResult.quoteNo);
        sessionStorage.setItem('addinf', JSON.stringify(this.responseJsonObj2));
        sessionStorage.setItem('portalform', JSON.stringify(this.tempPortalServiceInputObj));
        //  this.router.navigate(['addInfo',this.responseJsonObj2.quoteResult.quoteNo]);  
        this.router.navigateByUrl("/products/addInfo");
    }

    // all date convertion methods
    getDiffDays(startdate: Date, enddate: Date): any {
        // define moments for the startdate and enddate
        const startdateMoment = moment(startdate);
        const enddateMoment = moment(enddate);
        if (startdateMoment.isValid() === true && enddateMoment.isValid() === true) {
            // getting the difference in days
            return enddateMoment.diff(startdateMoment, 'days');
        }
        return undefined;
    }
    getDiffMonths(startdate: Date, enddate: Date): any {
        // define moments for the startdate and enddate
        const startdateMoment = moment(startdate);
        const enddateMoment = moment(enddate);
        if (startdateMoment.isValid() === true && enddateMoment.isValid() === true) {
            const years = enddateMoment.diff(startdateMoment, 'years');
            // getting the difference in months
            return enddateMoment.diff(startdateMoment, 'months') - (years * 12);
        }
        return undefined;
    }
    getDiffYears(startdate: Date, enddate: Date): any {
        // define moments for the startdate and enddate
        const startdateMoment = moment(startdate);
        const enddateMoment = moment(enddate);
        if (startdateMoment.isValid() === true && enddateMoment.isValid() === true) {
            // getting the difference in years
            return enddateMoment.diff(startdateMoment, 'years');
        }
        return undefined;
    }
    dateDiff(startdate: Date, enddate: Date): any {
        // define moments for the startdate and enddate
        const startdateMoment = moment(startdate);
        const enddateMoment = moment(enddate);

        if (startdateMoment.isValid() === true && enddateMoment.isValid() === true) {
            // getting the difference in years
            const years = enddateMoment.diff(startdateMoment, 'years');
            // moment returns the total months between the two dates, subtracting the years
            const months = enddateMoment.diff(startdateMoment, 'months') - (years * 12);
            // to calculate the days, first get the previous month and then subtract it
            startdateMoment.add(years, 'years').add(months, 'months');
            const days = enddateMoment.diff(startdateMoment, 'days');
            console.log(years + ' months ' + months + ' days ' + days);
        }
    }

    email = new FormControl('', [Validators.required, Validators.email]);
    //    rtoControl = new FormControl();
    //  this.rtoControl = new FormControl('', [Validators.required]);
    getErrorMessage() {
        return this.email.hasError('required') ? 'You must enter a value' :
            this.email.hasError('pattern') ? 'Not a valid email' :
                '';
    }

    getErrorMessageRTOLoc() {
        return this.rtoControl.hasError('required') ? 'Please select RTO Location' : '';

    }
    getErrorMessageMake() {
        return this.makeControl.hasError('required') ? 'Please select Make' : '';

    }
    getErrorMessageModel() {
        return this.modelControl.hasError('required') ? 'Please select Model' : '';

    }
    getErrorMessageVariant() {
        return this.variantControl.hasError('required') ? 'Please select Varient' : '';

    }
    payNow(){
    this.router.navigateByUrl("/products/payment");

  }

}
