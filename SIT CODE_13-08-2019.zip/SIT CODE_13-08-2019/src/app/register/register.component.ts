import { Component, OnInit } from '@angular/core';
import { RegisterService } from '../services/register.service';
import { Router } from '@angular/router';
import {FormControl} from '@angular/forms';
//import {MAT_MOMENT_DATE_FORMATS, MomentDateAdapter} from '@angular/material-moment-adapter';

//import moment from 'moment';
import { Agent } from '../model/agent';
import {MomentDateAdapter} from '@angular/material-moment-adapter';
import {DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE} from '@angular/material/core';

export const MY_FORMATS = {
  parse: {
    dateInput: 'D/MM/YYYY'
  },
  display: {
    dateInput: 'DD/MM/YYYY',
    monthYearLabel: 'MMMM Y',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'MMMM Y'
  },
};


@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css'],
  providers: [
    // `MomentDateAdapter` can be automatically provided by importing `MomentDateModule` in your
    // application's root module. We provide it at the component level here, due to limitations of
    // our example generation script.
    {provide: DateAdapter, useClass: MomentDateAdapter, deps: [MAT_DATE_LOCALE]},

    {provide: MAT_DATE_FORMATS, useValue: MY_FORMATS},
  ],
})


export class RegisterComponent implements OnInit {

  licenseNo:string;
  panNo:string;
  dob:string;
 
 //dob=_moment( this.dob, '',true).format("YYYY-MM-DD HH:mm:ss").toString();
  invalidAgent=false;
  errorMessage:string;

  maxDate = new Date();

  minDate = new Date();

  constructor(private router: Router,private registerService: RegisterService) { }

  ngOnInit() {
    this.minDate.setFullYear(this.maxDate.getFullYear() - 119); 
  }

  register(e,valid,regForm){
    if (e && !valid) {
      e.preventDefault();
    }

    if(valid){
    
    console.log(this.licenseNo);
    console.log(this.panNo);
    console.log(this.dob);
   let licenseNo=this.licenseNo;
   let dob=this.dob;
   let panNo=this.panNo;

  

    this.registerService.verifyRegisterService(licenseNo, panNo,dob)
      .subscribe(
        data => {
          console.log('In success block')
          let agent: Agent = data;
          if(agent.licenseNo!==null){
            sessionStorage.setItem('agent', JSON.stringify(agent));

            this.router.navigate(['verifyRegister'])
          }else if(data==='no data'){
            this.invalidAgent=true;
            this.errorMessage="Agent details not found! Please try again!"
          
            
          }

          
          //this.router.navigate(['register', this.username])
          //this.router.navigate(['verifyRegister'])
         
        },
        error => {

            this.invalidAgent=true;
            this.errorMessage="Agent details not found! Please try again!"
          
            
          
          console.log('error verifyregistration'+error.status+':'+error.statusText+':'+error.errorMessage);
         
        }
      )
    }
     
 regForm.resetForm();
    


  }


  resetForm(){
    this.licenseNo="";
    this.panNo="";
    this.dob="";
  }

  }


