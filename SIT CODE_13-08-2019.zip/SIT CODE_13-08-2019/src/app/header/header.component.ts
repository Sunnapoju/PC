import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';
import { AuthenticateService } from '../services/authenticate.service';
import { CommonServiceService } from '../services/common-service.service';
import * as _ from 'lodash';
@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  constructor(private router:Router,private authenticateService: AuthenticateService,private cs:CommonServiceService) { }
userData;
userName;
  ngOnInit() {
    //this.userData=JSON.parse( sessionStorage.getItem("userdata"));
   this.userData= this.cs.getUserData();
    console.log(this.userData);
    if(!_.isEmpty(this.userData)){
    this.userName=this.userData.FullName;

    }
  }
logOut(){
  this.authenticateService.logOut();
}
}
