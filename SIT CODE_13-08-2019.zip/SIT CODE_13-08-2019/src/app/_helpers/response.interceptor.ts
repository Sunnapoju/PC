import { Injectable } from '@angular/core';
import { HttpRequest, HttpHandler, HttpEvent, HttpInterceptor,HttpHeaders } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { Router } from '@angular/router';
import { AuthenticateService } from '../services/authenticate.service';

@Injectable({
    providedIn: 'root'
})
export class ResponseInterceptor implements HttpInterceptor {
   //constructor(private authenticationService: AuthenticationService) { }
    constructor(private router:Router,private authenticateService: AuthenticateService ) { }

    intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        
    request=   this.addToken(request);

        return next.handle(request).pipe(catchError(err => {
            if (err.status === 401) {
                alert("401");
                //this.router.navigateByUrl("/login");
               // this.authenticationService.logout();
                this.authenticateService.logOut();
            }


            const error = err.error.message || err.statusText;
            return throwError(error);
        }))
    }
    addToken(request){
        let userToken=sessionStorage.getItem("token");
        console.log(request.url);
        if((!request.url.includes("/authenticate")) && (!request.url.includes("/login"))){
     const authReq = request.clone({ setHeaders: { Authorization: userToken } });
      return authReq;
        }else{
            return request;
        }
    
}
}