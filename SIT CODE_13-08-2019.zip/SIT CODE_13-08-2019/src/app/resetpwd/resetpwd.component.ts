import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';
import { switchMap } from 'rxjs/operators';

@Component({
  selector: 'app-resetpwd',
  templateUrl: './resetpwd.component.html',
  styleUrls: ['./resetpwd.component.css']
})
export class ResetpwdComponent implements OnInit {

  username='';
  password='';
  mode='';
  ngOnInit() {
    this.route.params.subscribe(params => {
      this.username = params.user; // --> Name must match wanted parameter
    });
  }

  constructor(private route: ActivatedRoute,
    private router: Router) { }
login(){

}
resetForm(){

}
}
