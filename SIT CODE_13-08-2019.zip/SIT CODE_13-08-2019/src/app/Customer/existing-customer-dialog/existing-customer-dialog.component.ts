import { Component, OnInit } from '@angular/core';
import { CustomerService } from '../../services/customer.service';
import CustConstant from '../../data/customer.json';
import moment from 'moment';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import * as _ from 'lodash';
import ADDConstant from '../../data/add-constant.json';

@Component({
  selector: 'app-existing-customer-dialog',
  templateUrl: './existing-customer-dialog.component.html',
  styleUrls: ['./existing-customer-dialog.component.css']
})
export class ExistingCustomerDialogComponent implements OnInit {

  constructor(private customerService:CustomerService,public dialog: MatDialog ) { }

  ngOnInit() {

  }
public custId:string="";
public pan:string="";
public custName:string="";
public custType:string="Individual";
public dateOfBirth:string="";
public selectid;
isExistCust=false;
  tempNicPolicyCustSOABOObj = ADDConstant.nicPolicyCustSOABOObj;
   //tempNicPolicyCustSOABOObj2=PCConstant.nicPolicyCustSOABOObj;
public customersearchWithCustIdJson={
  customerType:"",
  customerCode:"",
  custName:"",
  pan:"",
  dateOfBirth:""

};
public customersearchWithoutCustIdJson={
  customerType:"",
  custName:"",
  pan:"",
  dateOfBirth:""

};
public tempcustomersearchJson={
  customerType:"",
  customerCode:"",
  custName:"",
  pan:"",
  dateOfBirth:""

};
public customerSearchResponse;
public customersArr=null;
tempCustIndObj = CustConstant.customerIndObject;
tempCustCorpObj = CustConstant.customerCorpObject;
showCustomerTable=false;
getCusomer(id){
  let custObj: any = _.find(this.customersArr, {
      'customerCode': id
    });
    return custObj;
}
 searchCustomer(event){
   //alert(this.dialogRef= this.customerService.getModalRef());
   //{"customerType":"Individual","customerCode":"","custName":"Shiva","pan":"AAAPL1234C","dateOfBirth":"05-06-1995"}
   if(this.custId==""){
      this.customersearchWithoutCustIdJson.customerType=this.custType;
      this.customersearchWithoutCustIdJson.custName=this.custName;
      this.customersearchWithoutCustIdJson.pan=this.pan;
      console.log(this.customersearchWithoutCustIdJson);
   if(this.dateOfBirth!=""){
      this.customersearchWithoutCustIdJson.dateOfBirth= moment(this.dateOfBirth).format("DD-MM-YYYY");
   }
   this.SearchCustomerService(this.customersearchWithoutCustIdJson);

   }else{
      this.customersearchWithCustIdJson.customerCode=this.custId;
      this.customersearchWithCustIdJson.customerType=this.custType;
      this.customersearchWithCustIdJson.custName=this.custName;
      this.customersearchWithCustIdJson.pan=this.pan;
      console.log(this.customersearchWithCustIdJson);
   if(this.dateOfBirth!=""){
      this.customersearchWithCustIdJson.dateOfBirth= moment(this.dateOfBirth).format("DD-MM-YYYY");
   }
   this.SearchCustomerService(this.customersearchWithCustIdJson);
   }
     
 }
SearchCustomerService(serachCustJson){
this.customerService.searchCustomer(serachCustJson).subscribe(result=>{
     this.customerSearchResponse=result;
     this.customersArr=this.customerSearchResponse.Customers;
     this.isExistCust=true;
     console.log(this.customersArr);
     
     this.showCustomerTable=true;
   },(e) => console.log(e), () => {
            console.log("error");
            console.log("inside error call",serachCustJson);
     });
}
existingCustDetials;
getExistCustDetailsById(custId){

   let obj= custId+";Individual";

  
  this.customerService.searchCustomerbyId(obj).subscribe(result=>{
     this.customerSearchResponse=result;
    
     console.log(this.customerSearchResponse.CustomerWithAddresses[0]);
     if(!_.isEmpty((this.customerSearchResponse.CustomerWithAddresses[0]))){
       this.setCustDataToJson(this.customerSearchResponse.CustomerWithAddresses[0]);
     }
     
   },error => {
        console.log("123");

      });
}
custJson;
 refresh(){
   this.custId="";
   this.pan="";
   this.custName="";
   this.dateOfBirth="";
 }
 dialogRef;
select(){

this.dialogRef= this.customerService.getModalRef();
this.custJson=this.getCusomer(this.selectid);
this.getExistCustDetailsById(this.custJson.customerCode);
this.tempcustomersearchJson.custName=this.convert(this.custJson.firstName.toLowerCase())+" "+this.convert(this.custJson.lastName.toLowerCase());
this.tempcustomersearchJson.customerCode=this.custJson.customerCode;
this.tempcustomersearchJson.customerType=this.custType.toUpperCase();

this.dialogRef.close(this.tempcustomersearchJson);
//portalServiceInputObj
  
}
 convert(name){
    return name.charAt(0).toUpperCase()+name.slice(1);
  }

setCustDataToJson(existCustData){
    this.tempNicPolicyCustSOABOObj.addressLine=existCustData.streetAddress;
    this.tempNicPolicyCustSOABOObj.city=existCustData.cityId;
    this.tempNicPolicyCustSOABOObj.country=existCustData.country;
    this.tempNicPolicyCustSOABOObj.district=existCustData.districtId;
    this.tempNicPolicyCustSOABOObj.email=existCustData.email;
    this.tempNicPolicyCustSOABOObj.firstName=existCustData.firstName;
    this.tempNicPolicyCustSOABOObj.gender=existCustData.genderId;
    this.tempNicPolicyCustSOABOObj.lastName=existCustData.lastName;
    this.tempNicPolicyCustSOABOObj.mobile=existCustData.mobile;
    this.tempNicPolicyCustSOABOObj.occupation=existCustData.occupationId;
    this.tempNicPolicyCustSOABOObj.postCode=existCustData.pinCd;
    this.tempNicPolicyCustSOABOObj.state=existCustData.stateId;
    this.tempNicPolicyCustSOABOObj.title=existCustData.title;
    this.tempNicPolicyCustSOABOObj.field10=moment(existCustData.dob).format("DD-MM-YYYY");
    this.tempNicPolicyCustSOABOObj.addressType=existCustData.addressTypeId;
    //PCConstant.nicPolicyCustSOABOObj=this.tempNicPolicyCustSOABOObj;
    ADDConstant.nicPolicyCustSOABOObj=this.tempNicPolicyCustSOABOObj;
   
  }
  
}
