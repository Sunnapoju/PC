import { Component, OnInit, Inject } from '@angular/core';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';
import CustConstant from '../../data/customer.json';
import {IndCustomer} from '../../model/ind-customer';
import {Address} from '../../model/address';
import {Industry} from '../../model/industry';
import {Title} from '../../model/title';
import {Organ} from '../../model/organ';
import {Occupation} from '../../model/occupation';
import {CorpCustomer} from '../../model/corp-customer';
import {CommunicationInfo} from '../../model/communication-info';
import moment from 'moment';
import { CustomerService } from '../../services/customer.service';
import { FormControl } from '@angular/forms';
import { Observable } from 'rxjs';
import { map, startWith } from 'rxjs/operators';
import * as _ from 'lodash';
import ADDConstant from '../../data/add-constant.json';

@Component({
  selector: 'app-new-customer-dialog',
  templateUrl: './new-customer-dialog.component.html',
  styleUrls: ['./new-customer-dialog.component.css']
})

export class NewCustomerDialogComponent implements OnInit {
  public customer: IndCustomer;


  tempCustIndObj = CustConstant.customerIndObject;
  tempCustCorpObj = CustConstant.customerCorpObject;
   tempNicPolicyCustSOABOObj = ADDConstant.nicPolicyCustSOABOObj;
 
  constructor(
    public dialogRef: MatDialogRef<NewCustomerDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: IndCustomer, private customerService: CustomerService) { }



  onNoClick(): void {
    this.dialogRef.close();
  }

  public addressArr: Address[] = null;
  public address: Address = null;
  public commInfo: CommunicationInfo;
  public pincode: string;
  public customerType: string;
  public cropCust: CorpCustomer;
  public indCust: IndCustomer;

  public firstName: string;
  public middleName: string;
  public lastName: string;
  public gender: string;
  public occupationDeatils: any;
  public dob: string;
  public cropName: string;
  public paidupCapital: any;
  public industryType: any;
  public moblino: string;
  public phoneNo: string;
  public email: string;
  public bName: string;
  public sName: string;
  public state: string;
  public country: string;
  public district: string;
  public locality: string;
  public city: string;
  public titleName: any;
  public sl_no: number;
  public pan: string;
  public indusType: any
  public organType: any;
  occupationJsonArr: any;
  titleJsonArr: any
  tempRespObj: any;

  titleControl = new FormControl();
  options: Title[];
  OccupationsArr: Occupation[];
  //occupation dropdown
  occupationControl = new FormControl();
  industryControl = new FormControl();
  organControl = new FormControl();
  //title: Observable<any[]>;
  occuObjArr: any;
  filterValue: any;
  indusTryTypeArr: any;
  organTypeArr: any;
  tempcommInfo: any;
  ngOnInit() {



    this.customerService.getOccupationAndTitle("OCCUPATION_TABLE_QUERY:CUST_TITLE_TABLE_QUERY:INDUSTRY_TYPE_TABLE_QUERY:ORGANIZATION_TYPE_TABLE_QUERY").subscribe(result => {
      this.tempRespObj = result;
      this.options = this.tempRespObj[0].CUST_TITLE_TABLE_QUERY;
      this.OccupationsArr = this.tempRespObj[0].OCCUPATION_TABLE_QUERY;
      this.indusTryTypeArr = this.tempRespObj[0].INDUSTRY_TYPE_TABLE_QUERY;
      this.organTypeArr = this.tempRespObj[0].ORGANIZATION_TYPE_TABLE_QUERY;
      this.bulidTitleOptions();
      this.bulidOccupationsOptions();
      this.bulidIndustryOptions();
      this.bulidOrganOptions();
      //this.buildOccupationDropdown(this.occupationJsonArr);
      console.log(this.tempRespObj);
    }, (e) => console.log(e), () => {
      console.log("error");

    });

    this.tempcommInfo = this.customerService.getCommInfo();
    this.email = this.tempcommInfo.gmail;
    if (!(this.tempcommInfo.mobNo == 0)) {
      this.moblino = this.tempcommInfo.mobNo;
    }
  }



  titleOptions: Observable<Title[]>;
  Occupations: Observable<Occupation[]>;
  industryOptions: Observable<Industry[]>;
  organOptions: Observable<Organ[]>;

  bulidTitleOptions() {
    this.titleOptions = this.titleControl.valueChanges
      .pipe(
      startWith(''),
      map(value => typeof value === 'string' ? value : value.name),
      map(name => name ? this._filterTitle(name) : this.options.slice())
      );
  }

  displayTitle(title?: Title): string | undefined {
    return title ? title.value : undefined;
  }
  private _filterTitle(name: string): Title[] {
    const filterValue = name.toLowerCase();

    return this.options.filter(option => option.value.toLowerCase().indexOf(filterValue) === 0);

  }
  //ocup
  bulidOccupationsOptions() {

    this.Occupations = this.occupationControl.valueChanges
      .pipe(
      startWith(''),
      map(value => typeof value === 'string' ? value : value.name),
      map(name => name ? this._filterOccupation(name) : this.OccupationsArr.slice())
      );
    console.log(this.Occupations);
  }
  displayOccupation(occup?: Occupation): string | undefined {
    return occup ? occup.value : undefined;
  }
  private _filterOccupation(name: string): Title[] {
    const filterValue = name.toLowerCase();

    return this.OccupationsArr.filter(occup => occup.value.toLowerCase().indexOf(filterValue) === 0);

  }

  //indNIC_INDUSTRY_TYPE_QUERY

  bulidIndustryOptions() {

    this.industryOptions = this.industryControl.valueChanges
      .pipe(
      startWith(''),
      map(value => typeof value === 'string' ? value : value.name),
      map(name => name ? this._filterIndustry(name) : this.indusTryTypeArr.slice())
      );
    console.log(this.Occupations);
  }

  displayIndustryOptions(indus?: Industry): string | undefined {
    return indus ? indus.value : undefined;
  }
  private _filterIndustry(name: string): Industry[] {
    const filterValue = name.toLowerCase();

    return this.indusTryTypeArr.filter(indus => indus.value.toLowerCase().indexOf(filterValue) === 0);

  }

  bulidOrganOptions() {

    this.organOptions = this.organControl.valueChanges
      .pipe(
      startWith(''),
      map(value => typeof value === 'string' ? value : value.name),
      map(name => name ? this._filterOrgan(name) : this.organTypeArr.slice())
      );
    console.log(this.Occupations);
  }

  displayOrganOptions(organ?: Organ): string | undefined {
    return organ ? organ.value : undefined;
  }

  private _filterOrgan(name: string): Organ[] {

    const filterValue = name.toLowerCase();
    return this.organTypeArr.filter(organ => organ.value.toLowerCase().indexOf(filterValue) === 0);

  }

  public district_id: number;
  public city_id: number;
  public state_id: number;
  getAddress(event) {

    this.customerService.getAddressDetailsByPincode(this.pincode).subscribe(result => {
      this.addressArr = <Address[]>(result);
      this.address = this.addressArr[0];
      console.log(this.address);
      console.log("Before error");
      if (this.address != null) {
        this.state = this.address.state_name;
        console.log("Setting values:" + this.state);
        this.city = this.address.city_name;
        this.country = "India";//this.address.Country""
        this.locality = this.address.locality;
        this.district = this.address.district_name;
        this.city_id = this.address.city_id;
        this.district_id = this.address.district_id;
        this.state_id = this.address.state_id;
        this.sl_no = this.address.sl_no;
      }
    }, (e) => console.log(e), () => {
      console.log("error");

    });
  }


  iscreateCustomer = false;
  public responseJson;
  createCustomer(event) {
    this.tempCustIndObj.dateOfBirth = moment(this.tempCustIndObj.dateOfBirth).format("DD-MM-YYYY");
    this.fillCustJSON(this.customerType);
    if (this.customerType == "Individual") {
      console.log(this.tempCustIndObj);
      this.customerService.createCustomer(this.tempCustIndObj).subscribe(response => {
        this.responseJson = response;
        this.iscreateCustomer = true;
        this.setCustDataToJson();
        this.closeModal(this.responseJson);
        
        //console.log(this.responseJson);

      }, (e) => console.log(e), () => {
        console.log("error");
      });
    }
    else if (this.customerType == "Corporate") {
      console.log(this.tempCustCorpObj);
      this.customerService.createCustomer(this.tempCustCorpObj).subscribe(result => {
        this.responseJson = result;
        console.log(this.responseJson);
        this.iscreateCustomer = true;
        this.closeModal(this.responseJson);
      }, (e) => console.log(e), () => {
        console.log("error");
      });
    }
    //console.log(this.responseJson);
  }
  getOccupationId(occupation) {
    let occupationObj: any = _.find(this.OccupationsArr, {
      'value': occupation
    });
    return occupationObj.id;
  }
  getTitleId(title) {
    let titleObj: any = _.find(this.options, {
      'value': title
    });
    return titleObj.id;
  }
  getIndusId(indus) {
    let indusObj: any = _.find(this.indusTryTypeArr, {
      'value': indus
    });
    return indusObj.id;
  }
  fillCustJSON(customerType) {
    if (customerType == "Individual") {
      this.tempCustIndObj.customerType = this.customerType;
      this.tempCustIndObj.firstName = this.firstName;
      this.tempCustIndObj.middleName = this.middleName;
      this.tempCustIndObj.lastName = this.lastName;
      this.tempCustIndObj.gender = this.gender;
      this.tempCustIndObj.occupation = (this.occupationDeatils.id).toString();
      this.tempCustIndObj.title = (this.titleName.id).toString();
      this.tempCustIndObj.dateOfBirth = moment(this.dob).format("DD-MM-YYYY");
      this.tempCustIndObj.address = this.bName +" "+ this.sName;
      this.tempCustIndObj.pinCd = (this.sl_no).toString();
      this.tempCustIndObj.beatCode = (this.sl_no).toString();
      this.tempCustIndObj.Pin_Sl_No = (this.sl_no).toString();
      this.tempCustIndObj.stateName = (this.address.state_id).toString();
      this.tempCustIndObj.country = "91";
      this.tempCustIndObj.districtName = (this.address.district_id).toString();
      this.tempCustIndObj.cityName = (this.address.city_id).toString();
      this.tempCustIndObj.mobileNo = this.moblino;
      this.tempCustIndObj.telephoneNumber = this.phoneNo;
      this.tempCustIndObj.pan=this.pan;


    } else if (this.customerType == "Corporate") {
      this.tempCustCorpObj.customerType = this.customerType;
      this.tempCustCorpObj.industryType = (this.indusType.id).toString();
      this.tempCustCorpObj.corporateName = this.cropName;
      this.tempCustCorpObj.paidupCapital = this.paidupCapital;
      this.tempCustCorpObj.address = this.bName + this.sName + this.locality;
      this.tempCustCorpObj.pinCd = (this.sl_no).toString();
      this.tempCustCorpObj.beatCode = (this.sl_no).toString();
      this.tempCustCorpObj.organizationType = (this.organType.id).toString();
      //this.tempCustCorpObj.Pin_Sl_No=(this.sl_no).toString();
      this.tempCustCorpObj.stateName = (this.address.state_id).toString();
      this.tempCustCorpObj.country = "91";
      this.tempCustCorpObj.districtName = (this.address.district_id).toString();
      this.tempCustCorpObj.cityName = (this.address.city_id).toString();
      this.tempCustCorpObj.mobileNo = this.moblino;
      //this.tempCustCorpObj.telephoneNumber=this.phoneNo;
    }


  }
  tempId
  tempJson = {
    custname: "",
    custId: "",
    custType: ""
  }
  closeModal(id) {
    //Created Successfully- Indi[9521185459]
    this.dialogRef = this.customerService.getModalRef();

    var res = id.split("-");
    var d = (res[1]).split("[");
    var e = d[1].slice(0, 10)
    this.tempJson.custId = e;
    this.tempJson.custType = this.customerType;
    if (this.customerType === "Individual") {
      if(this.middleName!=null && this.middleName!=""){
      this.tempJson.custname = this.convert(this.firstName.toLowerCase()) +" " +this.convert(this.middleName.toLowerCase()) +" "
       + this.convert(this.lastName.toLowerCase());
      }else{
         this.tempJson.custname = this.convert(this.firstName.toLowerCase()) +" "
        this.convert(this.lastName.toLowerCase());
      }
    } else {
      this.tempJson.custname = this.convert(this.cropName);
    }
    this.dialogRef.close(this.tempJson);
  }
  convert(name) {
    return name.charAt(0).toUpperCase() + name.slice(1);
  }

  getErrorMessageTitle() {
    return this.titleControl.hasError('required') ? 'Please select Title' : '';

  }
  getErrorMessageOccupation(){
    return this.occupationControl.hasError('required') ? 'Please select Occupation' : '';
  }
  getErrorMessageIndustryType(){
     return this.industryControl.hasError('required') ? 'Please select Industry Type' : '';
  }
  getErrorMessageOrgnizationType(){    
     return this.organControl.hasError('required') ? 'Please select Organization Type' : '';
  }
  setCustDataToJson(){
    this.tempNicPolicyCustSOABOObj.addressLine=this.bName +" "+ this.sName;
    this.tempNicPolicyCustSOABOObj.city=(this.address.city_id).toString();
    this.tempNicPolicyCustSOABOObj.country='91';
    this.tempNicPolicyCustSOABOObj.district=(this.address.district_id).toString();
    this.tempNicPolicyCustSOABOObj.email=this.email;
    this.tempNicPolicyCustSOABOObj.firstName=this.firstName+" "+this.middleName;
    this.tempNicPolicyCustSOABOObj.gender=this.gender;
    this.tempNicPolicyCustSOABOObj.lastName=this.lastName;
    this.tempNicPolicyCustSOABOObj.mobile=this.moblino;
    this.tempNicPolicyCustSOABOObj.occupation=(this.occupationDeatils.id).toString();
    this.tempNicPolicyCustSOABOObj.postCode=(this.sl_no).toString();
    this.tempNicPolicyCustSOABOObj.state=(this.address.state_id).toString();
    this.tempNicPolicyCustSOABOObj.title=(this.titleName.id).toString();
    this.tempNicPolicyCustSOABOObj.field10=moment(this.dob).format("DD-MM-YYYY");
    //PCConstant.nicPolicyCustSOABOObj=this.tempNicPolicyCustSOABOObj;
    ADDConstant.nicPolicyCustSOABOObj=this.tempNicPolicyCustSOABOObj;
   
  }
}


