

export const API_URL = "http://nic-tuport1a-ac.nic.co.in:8001/myweb/"



//export const API_URL = "http://localhost:7001/"
/* Session Timeout Data */

export const sessionTimeOut=600;
