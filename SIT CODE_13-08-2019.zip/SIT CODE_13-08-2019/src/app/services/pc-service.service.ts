import { Injectable } from '@angular/core';
import { API_URL } from '../app.constants';
import { Observable } from 'rxjs';
import { map, startWith } from 'rxjs/operators';
import {Rto} from '../model/rto';
import { HttpHeaders, HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})


export class PcServiceService {


private BASE_URL = API_URL;
regNum='RTOCODE_TABLE_QUERY_FROM_REG:'
  constructor( private httpClient: HttpClient) { }
userToken;
   getRTOCodeFromReg(data): Observable < Rto[] > {
    this.setToken();
    data=this.regNum+data;
    console.log("Service:"+data);
    return this.httpClient.post < Rto[] > (this.BASE_URL + 'quote/getRTOCodeFromReg', data,{ responseType: 'json'});
  }
  setToken(){
this.userToken=sessionStorage.getItem("token");
}
}
