import { TestBed } from '@angular/core/testing';

import { PcServiceService } from './pc-service.service';

describe('PcServiceService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: PcServiceService = TestBed.get(PcServiceService);
    expect(service).toBeTruthy();
  });
});
