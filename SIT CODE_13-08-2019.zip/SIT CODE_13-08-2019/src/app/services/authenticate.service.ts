import { Injectable } from '@angular/core';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import {map} from 'rxjs/operators';
import { API_URL } from './../app.constants';
import { Router } from '@angular/router';

export const TOKEN = 'token'
export const AUTHENTICATED_USER = 'authenticaterUser'

@Injectable({
  providedIn: 'root'
})
export class AuthenticateService {

  constructor(private http: HttpClient,private router:Router) { }

private BASE_URL = API_URL;
  executeJWTAuthenticationService(username, password) {
    console.log("Service call");
    return this.http.post<any>(
      
      `${API_URL}authenticate`,{
        username,
        password
      }).pipe(
        map(
          data => {
            sessionStorage.setItem(AUTHENTICATED_USER, username);
            sessionStorage.setItem(TOKEN, `Bearer ${data.token}`);
            return data;
          }
        )
      );


      
    //console.log("Execute Hello World Bean Service")
  }


  isUserLoggedIn() {
    let user = sessionStorage.getItem(AUTHENTICATED_USER);
    let token=sessionStorage.getItem(TOKEN);
   if(user!=null && token!=null){
     return true;
   }else{
     return false;
   }
  }
logOut(){
localStorage.clear(); 
sessionStorage.clear();
this.router.navigateByUrl("/login");

}
searchAgent(partyId){

     console.log("inside service call",partyId);
 return this.http.post(this.BASE_URL  + 'login/agentDetails',partyId,
        { responseType: 'json'});
}
}
