import { Injectable } from '@angular/core';
import { AuthenticateService } from '../services/authenticate.service';
import { UserIdleService, UserIdleConfig } from 'angular-user-idle';
import { Router } from '@angular/router';
import { sessionTimeOut } from '../app.constants';
@Injectable({
  providedIn: 'root'
})
export class IdealService {

  constructor(private userIdle: UserIdleService,private _route: Router,private authenticateService: AuthenticateService) { }
//et the session time out value from app constants  
_sessionTimeOut=sessionTimeOut;
      start() {
          console.log("inside idel timeout");
          this.stopWatching();
       const _idle = new UserIdleConfig();
       // Get the session time out value from properties file
       _idle.idle = this._sessionTimeOut;

       _idle.timeout = 1;
       // Setting the configuration values to ideal module
       this.userIdle.setConfigValues(_idle);
        // Start watching for user inactivity.
        this.userIdle.startWatching();
        // Start watching when user idle is starting.
        console.log("inside idel timeout", this.userIdle);
        this.userIdle.onTimerStart().subscribe(count => 
        console.log("count",count)
        );
        // Start watch when time is up.
        this.userIdle.onTimeout().subscribe(() => {
              console.log("inside idel onTimeout", this.userIdle);
            this.authenticateService.logOut();
             this.stopWatching();
        });
    }

    stop() {
        this.userIdle.stopTimer();
    }

    stopWatching() {
        this.userIdle.stopWatching();
    }

    startWatching() {
        this.userIdle.startWatching();
    }

    restart() {
        this.userIdle.resetTimer();
    }



}

