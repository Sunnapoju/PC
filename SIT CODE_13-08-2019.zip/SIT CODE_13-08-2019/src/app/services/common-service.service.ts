import { Injectable } from '@angular/core';
import {Subject} from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class CommonServiceService {
common;
planId;
planName;
AgreementCodeData
userData;
  constructor() {
    this.common = new Subject();
    
   }
  
  setPlanId(planId){
    this.planId=planId;
  }
  getPlanId(){
    return this.planId;
  }
  setPlanName(planName){
    this.planName=planName;
  }
  getPlanName(){
    return this.planName;
  }
  setAgreementCode(AgreementArr){
    this.AgreementCodeData=AgreementArr;
  }
  getAgreementCode(){
     return this.AgreementCodeData;
  }
  setUserData(userData){
this.userData=userData;
  }
  getUserData(){
    return this.userData;
  }
}
