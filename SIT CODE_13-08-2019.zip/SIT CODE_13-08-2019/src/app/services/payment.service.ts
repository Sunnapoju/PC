import { Injectable } from '@angular/core';
import { API_URL } from '../app.constants';
import { Observable } from 'rxjs';
import { map, startWith } from 'rxjs/operators';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { DepositAccounts } from '../model/depositeAccounts';


@Injectable({
  providedIn: 'root'
})
export class PaymentService {

  private BASE_URL = API_URL;


  constructor(private httpClient: HttpClient) { }



  getBankDetailsByIfsc(data) {
    console.log("getBankDetailsByIfsc service called");
    return this.httpClient.post(this.BASE_URL + 'payment/getBankDetails', data, { headers: new HttpHeaders({ 'Content-Type': 'text/plain' }), responseType: 'text' });   
  }

  goToBillDesk(data) {
    //console.log(data);
    return this.httpClient.post(this.BASE_URL + 'payment/getBillUrl', data, { headers: new HttpHeaders({ 'Content-Type': 'text/plain' }), responseType: 'text' });


  }

  payCustomerDeposit(data) {
    console.log("payCustomerDeposit service called");
    return this.httpClient.post(this.BASE_URL + 'payment/payCustomerDeposit', data, { headers: new HttpHeaders({ 'Content-Type': 'text/plain' }), responseType: 'text' });
  }
   payThroughCheque(data) {
    console.log("cheque paymode service called");
    return this.httpClient.post(this.BASE_URL + 'payment/chequePaymode', data, { headers: new HttpHeaders({ 'Content-Type': 'text/plain' }), responseType: 'text' });
  }
 

  checkBal(data) {
    console.log("check Bal service called");
    return this.httpClient.post(this.BASE_URL + 'payment/checkBal', data, { headers: new HttpHeaders({ 'Content-Type': 'text/plain' }), responseType: 'text' });
 
  }


  downloadPolicy(data){  
    console.log("download Policy service called");
    return this.httpClient.post(this.BASE_URL + 'payment/downloadPolicy', data,{ headers: new HttpHeaders({ 'Content-Type': 'text/plain' }), responseType: 'text' } );
  }


}
 