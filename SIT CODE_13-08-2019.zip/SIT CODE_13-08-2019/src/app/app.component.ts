import { Component, OnInit } from '@angular/core';
import { IdealService } from './services/ideal.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent implements OnInit {
  title = 'PortalLite';
  constructor(private _idealService : IdealService) { }
ngOnInit(){
  
}
}
