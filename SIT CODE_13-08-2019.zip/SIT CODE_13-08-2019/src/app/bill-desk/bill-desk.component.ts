import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bill-desk',
  templateUrl: './bill-desk.component.html',
  styleUrls: ['./bill-desk.component.css']
})
export class BillDeskComponent implements OnInit {

  constructor() { }

  ngOnInit() {
    console.log("inside the bill desk");
  }

}
