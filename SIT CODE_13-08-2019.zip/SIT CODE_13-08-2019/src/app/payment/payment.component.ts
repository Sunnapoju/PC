import { Component, OnInit } from '@angular/core';
import ADDConstant from '../data/add-constant.json';
import { PaymentService } from '../services/Payment.service';
import { DepositAccounts } from '../model/depositeAccounts';
import { FormControl } from '@angular/forms';
import { CommonServiceService } from '../services/common-service.service';
import { DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE } from '@angular/material/core';
import { MomentDateAdapter } from '@angular/material-moment-adapter';
import moment from 'moment';
import { saveAs } from 'file-saver';

export const MY_FORMATS = {
  parse: {
    dateInput: 'D/MM/YYYY'
  },
  display: {
    dateInput: 'DD/MM/YYYY',
    monthYearLabel: 'MMMM Y',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'MMMM Y'
  },
};

@Component({
  selector: 'app-payment',
  templateUrl: './payment.component.html',
  styleUrls: ['./payment.component.css'],
  providers: [{ provide: DateAdapter, useClass: MomentDateAdapter, deps: [MAT_DATE_LOCALE] },
  { provide: MAT_DATE_FORMATS, useValue: MY_FORMATS },
  ],
})


export class PaymentComponent implements OnInit {

  cdpdAccControl = new FormControl();
  //cheque Paymode data members
  chequeNum;
  chequeDate = new Date();
  chequeAmount;
  chequeType;
  ifscCode;
  bankName;
  bankNo
  branchName;
  branchNo;
  // micrCode;
  responce;

  userDataString;
  public bankDetailsArray;
  bankDetails;

  // for payment reciept 

  productName;
  transactionNumber;
  policyNumber;
  recieptNumber;
  proposalNumber;
  RecieptDate;
  balanceAmount;
  premiumPaid;
  gotResponceFromPaymode = false;
  isPaymentPending = true;
  insufficientBal = false;

  //policyPdf data members

  policyPdfResponce;
  policyPdfFinalString;
  recieptPdfStr;
  recieptPdfFinalStr;
  downloadPdf = false;

  constructor(private paymentService: PaymentService, private cs: CommonServiceService) { }
  paymentType: any
  temppolicySOABO = ADDConstant.policySOABO;
  agentCode: any;
  depositAccountsArray: DepositAccounts[];
  payModeType: any

  agentCDPDAccNum;
  agentAllowCDPDAccNum;
  quote;
  premium;
  tempresponse;
  billDeskRequestUrl;
  custid;
  custCDPDAccNum;
  isBillDesk = false;
  isShow = true;
  isCheckBal = false;
  isPaymentSuccess = false;
  isAlreadyIssued = false;

  tempCustmerDeposit = {
    custId: "",
    premium: "",
    custName: "",
    productCode: "",
    productName: "",
    branchId: "",
    agentCode: "",
    agentName: "",
    quoteNo: "",
    cdAccountNo: "",
    payModeType: ""
  }
  tempChequePaymode = {
    custId: "",
    premium: "",
    custName: "",
    productCode: "",
    productName: "",
    branchId: "",
    agentCode: "",
    quoteNo: "",
    cdAccountNo: "",
    payModeType: "",
    chequeNo: "",
    chequeDate: "",
    chequeAmnt: "",
    chequeType: "",
    ifscCode: "",
    bankNo: "",
    bankName: "",
    branchNo: "",
    branchName: "",
    //   micrCode:"",
    agentName: ""
  }

  policyPdfJsonReqObj = {
    policyNo: "",
    printType: "",
    Field1: ""
  }

  ngOnInit() {
    this.agentCode = this.temppolicySOABO.agentCode;
    this.agentCDPDAccNum = this.temppolicySOABO.agentCode;
   
    
      this.tempSessionObj = JSON.parse(sessionStorage.getItem('userData'));
      this.quote = this.tempSessionObj.quoteNo;
      console.log(this.tempSessionObj.quoteNo);
      console.log(this.quote);
      this.premium = this.tempSessionObj.premium.toString();
      console.log(this.tempSessionObj.premium.toString());
      console.log(this.premium);
      //  this.premium = this.tempresponse.premium;


    

    //  this.quote = "NICQ1900010229";
    //  this.premium = "38088";
    // this.agentCode = "9000008029"
    //  this.custid = "9520975866"
  }

  /* chequeAmt(chequeAmount) {
 
   }*/



  getBankDetails(isValid) {
    this.ifscCode = this.ifscCode.toUpperCase();
    this.bankName = null;
    this.branchName = null;
    if (this.ifscCode.length === 11) {
      this.paymentService.getBankDetailsByIfsc(
        "'" + this.ifscCode + "'").subscribe(result => {
          console.log(" original result" + result);
          this.responce = result;
          this.bankDetailsArray = JSON.parse(this.responce);;
          console.log("bankDetailsArray" + this.bankDetailsArray);
          this.bankDetails = this.bankDetailsArray[0];
          console.log("bankDetails" + this.bankDetails);
          if (this.bankDetails != null) {
            console.log(this.bankDetails);
            this.bankName = this.bankDetails.bank_nm;
            this.branchName = this.bankDetails.bank_branch_name;
            this.bankNo = this.bankDetails.bank_cd;
            this.branchNo = this.bankDetails.bank_branch_cd;
            //  this.micrCode=this.bankDetails.micr_code;
          }
        }, (e) => console.log(e), () => {
          console.log("error");

        });
    }
  }

  PaymentMode() {
    this.insufficientBal=false;
    this.isCheckBal = false;
    this.isPaymentSuccess = false;
    this.isAlreadyIssued = false;
    console.log(this.temppolicySOABO.agentCode);
    console.log(this.agentCode);

    if (this.paymentType === '1') {
      this.getBillDesk();
    }
    if (this.paymentType === '4') {

    }

  }

  getBillDesk() {
    //  this.isShow = false;
    // this.quote = "NICQ1900010229";
    // this.permium = "38088";
    // this.agentCode="9000008029";
    // this.custid="9520977405";

    this.paymentService.goToBillDesk(this.quote + ":" + this.premium + ":" + this.agentCode + ":" + this.custid).subscribe(result => {

      console.log(result);
      this.isBillDesk = true;
      this.billDeskRequestUrl = result;
    }, (e) => console.log(e), () => {

      console.log("123");

    });
  }
  accountNo;
  cdres;
  checkBalRes;
  checkBalResJson;
  paymentResJson;
  availaBal;
  genPolicyNo;
  tempSessionObj;

  isCDInVaild = false;
  payThroughCustomerDeposit() {
    console.log("after pay now method, payThroughCustomerDeposit called");
    this.tempSessionObj = JSON.parse(sessionStorage.getItem('userData'));
    console.log("userData" + sessionStorage.getItem('userData'));
    console.log("user data after conversion from string to json " + this.tempSessionObj);

    this.tempCustmerDeposit.custId = this.tempSessionObj.customer.custId;
   // this.tempCustmerDeposit.custId = '9520975866';
    this.custid = this.tempCustmerDeposit.custId;
    this.tempCustmerDeposit.premium = this.tempSessionObj.premium.toString();
    // this.premium = this.tempCustmerDeposit.premium;
    this.tempCustmerDeposit.custName = this.tempSessionObj.customer.custName;
    this.tempCustmerDeposit.branchId = this.tempSessionObj.branchId;
    this.tempCustmerDeposit.quoteNo = this.tempSessionObj.quoteNo;
    // this.quote = this.tempCustmerDeposit.quoteNo;
    this.tempCustmerDeposit.productCode = this.tempSessionObj.productCode;
    this.tempCustmerDeposit.productName = this.tempSessionObj.productName;
    this.productName = this.tempSessionObj.productName;
    this.tempCustmerDeposit.agentCode = this.tempSessionObj.agentCode;
    this.tempCustmerDeposit.agentName = this.tempSessionObj.agentName;
    //this.tempCustmerDeposit.agentName = "HARINI PALIKARANAI";

    if (this.paymentType === '2') {
      this.tempCustmerDeposit.cdAccountNo = this.custCDPDAccNum;
    }

    else if (this.paymentType === '3') {
      this.tempCustmerDeposit.cdAccountNo = this.agentCDPDAccNum;
    }
    this.tempCustmerDeposit.payModeType = this.payModeType;

    console.log("customer deposit account" + this.tempCustmerDeposit.cdAccountNo);

    console.log("tempCustmerDeposit formed object" + this.tempCustmerDeposit);

    this.paymentService.payCustomerDeposit(JSON.stringify(this.tempCustmerDeposit)).subscribe(result => {

      this.cdres = result;
      if (this.cdres != null) {
        this.gotResponceFromPaymode = true;

      }
      console.log("payment result string " + this.cdres);
      this.paymentResJson = JSON.parse(this.cdres);
      if (this.paymentResJson.responseCode === "8028") {
        this.isAlreadyIssued = true;
        this.isPaymentSuccess = false;
        this.isPaymentPending = true;
      }
      else if (this.paymentResJson.responseCode === "999") {
        this.isAlreadyIssued = false;
        if (this.paymentResJson.hasOwnProperty("policyNo")) {
          this.insufficientBal = false;
          this.isPaymentSuccess = true;
          this.isPaymentPending = false;
          this.genPolicyNo = this.paymentResJson.policyNo;
          this.genPolicyNo = this.genPolicyNo.replace(";", "");
          this.transactionNumber = this.paymentResJson.TransNum;
          this.policyNumber = this.genPolicyNo;
          this.recieptNumber = this.paymentResJson.receiptNo;
          this.recieptNumber = this.recieptNumber.replace(";", "");
          this.proposalNumber = this.paymentResJson.proposalNo;
          this.proposalNumber = this.proposalNumber.replace(";", "");
          this.premiumPaid = this.paymentResJson.app;
          this.premiumPaid = this.premiumPaid.replace(";", "");
          this.RecieptDate = this.paymentResJson.receiptDate;
          this.recieptPdfStr=this.paymentResJson.pdf;
        } else {
          this.insufficientBal = true;
          this.isPaymentPending = true;
          this.isPaymentSuccess = false;
          this.balanceAmount = this.paymentResJson.balanceAmount;
        }
      }
    }, error => {
      console.log("123");
      this.isCDInVaild = true;

    });
  }

  payThroughCheque() {

    console.log("after pay now method, payThroughCheque called");
    this.tempSessionObj = JSON.parse(sessionStorage.getItem('userData'));
    console.log("userData" + sessionStorage.getItem('userData'));
    console.log("user data after conversion from string to json " + this.tempSessionObj);
    this.tempChequePaymode.custId = this.tempSessionObj.customer.custId;
    //this.tempChequePaymode.custId = '9520975866';
    this.custid = this.tempChequePaymode.custId;
    this.tempChequePaymode.premium = this.tempSessionObj.premium.toString();
    //this.premium = this.tempChequePaymode.premium;
    this.tempChequePaymode.custName = this.tempSessionObj.customer.custName;
    //this.tempChequePaymode.custName = 'Lakshman K';
    this.tempChequePaymode.branchId = this.tempSessionObj.branchId;
    console.log("this.tempChequePaymode.branchId" + this.tempChequePaymode.branchId);
    this.tempChequePaymode.quoteNo = this.tempSessionObj.quoteNo;

    // this.quote = this.tempChequePaymode.quoteNo;
    this.tempChequePaymode.payModeType = this.payModeType;
    this.tempChequePaymode.productCode = this.tempSessionObj.productCode;
    this.tempChequePaymode.productName = this.tempSessionObj.productName;
    this.productName = this.tempSessionObj.productName;
    this.tempChequePaymode.agentCode = this.tempSessionObj.agentCode;
    this.tempChequePaymode.agentName = this.tempSessionObj.agentName;
    //this.tempChequePaymode.agentName = "HARINI PALIKARANAI";
    this.tempChequePaymode.chequeNo = this.chequeNum.toString();
    this.tempChequePaymode.chequeDate = moment(this.chequeDate).format("DD/MM/YYYY");
    this.tempChequePaymode.chequeAmnt = this.chequeAmount;
    this.tempChequePaymode.chequeType = this.chequeType;
    console.log(" this.chequeType" + this.chequeType);
    this.tempChequePaymode.ifscCode = this.ifscCode;
    this.tempChequePaymode.bankNo = this.bankNo.toString();
    this.tempChequePaymode.bankName = this.bankName;
    this.tempChequePaymode.branchNo = this.branchNo.toString();
    this.tempChequePaymode.branchName = this.branchName;
    //this.tempChequePaymode.micrCode=this.micrCode;
    console.log("tempChequePaymode formed object" + this.tempChequePaymode);
    this.paymentService.payThroughCheque(JSON.stringify(this.tempChequePaymode)).subscribe(result => {

      this.cdres = result;
      if (this.cdres != null) {
        this.gotResponceFromPaymode = true;
        this.isPaymentPending = false;
      }
      console.log("payment result string " + this.cdres);
      this.paymentResJson = JSON.parse(this.cdres);


      if (this.paymentResJson.responseCode === "999") {
        this.isPaymentSuccess = true;
        this.isAlreadyIssued = false;
        this.genPolicyNo = this.paymentResJson.policyNo;
        this.genPolicyNo = this.genPolicyNo.replace(";", "");
        this.transactionNumber = this.paymentResJson.TransNum;
        this.policyNumber = this.genPolicyNo;
        this.recieptNumber = this.paymentResJson.receiptNo;
        this.recieptNumber = this.recieptNumber.replace(";", "");
        this.proposalNumber = this.paymentResJson.proposalNo;
        this.proposalNumber = this.proposalNumber.replace(";", "");
        this.premiumPaid = this.paymentResJson.app;
        this.premiumPaid = this.premiumPaid.replace(";", "");
        this.RecieptDate = this.paymentResJson.receiptDate;
        this.recieptPdfStr=this.paymentResJson.pdf;
      }
      else if (this.paymentResJson.responseCode === "8028") {
        this.isAlreadyIssued = true;
        this.isPaymentSuccess = false;
        this.isPaymentPending = true;
      }
      else{
        
      }
    }, error => {
      console.log("123");
      this.isCDInVaild = true;

    });
  }
  payNow(paymentType) {
   
    this.isCheckBal = false;
    console.log("pay now method called");
    if (this.paymentType === '2') {
      this.payModeType = "CustomerDeposit";
      this.payThroughCustomerDeposit();
    }

    else if (this.paymentType === '3') {
      this.payModeType = "AgentDeposit";
      this.payThroughCustomerDeposit();
    }
    else if (this.paymentType === '4') {
      this.payModeType = "Cheque";
      this.payThroughCheque();
    }
  }

  checkBal(paymentType) {

    console.log("check Bal method called");

    if (this.paymentType === '3') {
      this.accountNo = this.agentCDPDAccNum;
    }

    console.log("check bal account" + this.accountNo);

    this.paymentService.checkBal(this.accountNo).subscribe(result => {
      this.checkBalRes = result;
      console.log("check bal res" + this.checkBalRes);
      this.checkBalResJson = JSON.parse(this.checkBalRes);
      this.availaBal = this.checkBalResJson.balanceAmount;

      this.isCheckBal = true;

    }, error => {
      console.log("123");
    });
  }

  downloadPolicy() {
    this.policyPdfJsonReqObj.policyNo = this.policyNumber;
    this.policyPdfJsonReqObj.printType = "policy";
    this.policyPdfJsonReqObj.Field1 = "1";

    this.paymentService.downloadPolicy(JSON.stringify(this.policyPdfJsonReqObj)).subscribe(result => {

      this.policyPdfResponce = result;
      if (this.policyPdfResponce != null) {
        console.log("policyPdfResponce " + this.policyPdfResponce);
        this.policyPdfFinalString = "data:application/pdf;base64," + this.policyPdfResponce;
        console.log(this.policyPdfFinalString);
        saveAs(this.policyPdfFinalString, this.policyNumber + ".pdf");
      }
    }, error => {
      console.log(" error in policyPdfResponce");
    });

  }
  downloadReciept(){
    this.recieptPdfFinalStr="data:application/pdf;base64," + this.recieptPdfStr;
    saveAs(this.recieptPdfFinalStr, this.recieptNumber + ".pdf");
  }

}
 

